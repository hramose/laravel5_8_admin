<?php
    $imageSize = 1024 * 2;
    
    return [    
        'ImageSize' => $imageSize,
        'ThumbWidth' => 440,
        'ThumbHeight' => 442,

        'EmptyNotation' => ' - ',
        'NoImageIcon' => '/public/images/common/no_image.jpg',
        'NoImage50Icon' => '/public/images/common/no_image_50.jpg'
    ];
