@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{$mainTitle}}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title"> {{$subTitle}}</h3>
                        </div>
                        
                        @if(!empty($subscription))
                            {{ Form::model($subscription, array('route' => array('subscriptions.update', \Crypt::encryptString($subscription->id)), 'method' => 'PUT', 'id'=>'subscriptionForm')) }}
                        @else
                            {!! Form::open(array('url' => env('ADMIN_URL') . '/subscriptions', 'id' => 'subscriptionForm')) !!}
                        @endif
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Name</label>
                                            {{ Form::text('name', null, array('class'=>'form-control required', 'minlength'=>'5', 'maxlength' => '191')) }}
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Price <small>({{ CommonHelper::fetchGlobalSettingValueByName('CurrencySign') }})</small></label>
                                            {{ Form::text('price', null, array('class'=>'form-control required number')) }}
                                        </div>
                                    </div>
                                    
                                    
                                </div>
                                
                                <div class="row">
                                <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Subscription Type</label>
                                            {{ Form::Select('type', $subscriptionType, null, ['class'=>'form-control required']) }}
                                        </div>
                                    </div> 

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Status</label>
                                            <div>
                                                {{ Form::Select('status', $status, null, ['placeholder'=>'- Select -', 'class'=>'form-control required']) }} 
                                            </div>
                                        </div>
                                    </div>    
                                </div>
                                                                
                                <div class="row">
                                <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Description</label>
                                            {{ Form::textarea('description', null, array('class'=>'form-control required', 'minlength'=>'5')) }}
                                        </div> 
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2  col-md-4">
                                        {{ Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat')) }}
                                    </div>
                                </div>
                            {{Form::close()}}
                        </div>
                    </div>
                </div>
        </section>
    </div>            
    
    <script>        
        $(document).ready(function () {
            $('#subscriptionForm').validate();
        });
    </script>
@endsection