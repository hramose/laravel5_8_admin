@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{$mainTitle}}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-body">
                            <table  class="table">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>Description</th>
                                        <th>Price</th> 
                                        <th>Subscription Type</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                @if(!empty($subscription))
                                @php $statusClasses = ['Active' => 'label-success', 'Inactive' => 'label-danger']; @endphp
                                    <tbody>
                                            <tr>
                                                <td>{{ !empty($subscription->name) ? $subscription->name : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ !empty($subscription->description) ? $subscription->description : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ !empty($subscription->price) ? CommonHelper::fetchGlobalSettingValueByName('CurrencySign') . $subscription->price : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ !empty($subscription->price) ? $subscription->type : \Config::get('constants.EmptyNotation') }}</td>
                                                <td data="{{ \Crypt::encryptString($subscription->id) }}" model="{{ \Crypt::encryptString('subscriptions')}}" class="change-status-confirm {{ $subscription->status }}" title="Change Status"><span class="label {{ $statusClasses[$subscription->status] }}" id="status-{{ $subscription->id }}">{{ $subscription->status }}</span></td>
                                                <td class="action-btn">
                                                    {!! Form::open(['method' => 'GET', 'route' => ['subscriptions.edit', \Crypt::encryptString($subscription->id)]]) !!}
                                                        {!! Form::button('', array('type' => 'submit', 'class' => 'pull-left fa fa-edit text-success', 'title' => 'Edit Subscription')) !!}
                                                    {!! Form::close() !!}
                                                </td>
                                            </tr>
                                        
                                    </tbody>
                                @endif
                            </table>
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    @include('admin.elements.js.common')
@endsection