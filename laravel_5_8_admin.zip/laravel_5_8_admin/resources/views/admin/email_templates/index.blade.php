@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">	
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>
        
        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <div class="box-body">
                            <table class="table">
                                <thead>                     
                                    <tr>
                                        <th>@sortablelink('id', 'ID')</th>
                                        <th>@sortablelink('name',)</th>
                                        <th>@sortablelink('subject')</th>
                                        <th>Body</th>
                                        <th>Action</th>
                                    </tr>					    
                                </thead>

                                <tbody>
                                    @if(count($emailTemplateList))
                                        @foreach($emailTemplateList as $emailTemplate)
                                            <tr>
                                                <td>{{ $emailTemplate->id }}</td>
                                                <td>{{ !empty($emailTemplate->type) ? $emailTemplate->type : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ !empty($emailTemplate->subject) ? $emailTemplate->subject : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ !empty($emailTemplate->body) ? str_limit(strip_tags(html_entity_decode($emailTemplate->body)), $limit = 50, $end = '...') : \Config::get('constants.EmptyNotation') }}</td>
                                                <td class="action-btn">
                                                    {{ Form::open(['method'=>'GET', 'route'=>['email-templates.edit', \Crypt::encryptString($emailTemplate->id)]]) }}
                                                        {{ Form::button('', array('type'=>'submit', 'class'=>'fa fa-edit text-success', 'title'=>'Edit Email Template')) }}
                                                    {{ Form::close() }}
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <td colspan="4" class="error-msg">{{ __('messages.NotFound.EmailTemplate') }}</td>
                                    @endif                                     
                                </tbody>
                            </table>
                            
                            @if(count($emailTemplateList))    
                                <div class="col-lg-12">
                                    <div class="pagination">{!! $emailTemplateList->appends(request()->query())->links() !!}</div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    @include('admin.elements.js.common')
@endsection