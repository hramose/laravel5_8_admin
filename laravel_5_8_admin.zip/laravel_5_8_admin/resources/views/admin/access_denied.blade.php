@extends('admin.layout.admin_access_denied')

@section('content')    
    <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12 acess_deny">
            <span class="image">{{ Html::image(asset('/public/images/common/access-denied.png'), 'image') }}</span>

            <span class="hd">Access Denied</span>

            <p class="gen_txt">You do not have permission to access this page.</p>

            <a href="{{ url('/admin') }}" class="btn btn-info btn-lg">Home</a>
        </div>
    </div>
@endsection