<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        
        <title>{{ config('SiteName') }}: Admin</title>
        
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        
        <link href="{{ asset('/public/css/admin/bootstrap.min.css') }}" rel="stylesheet">	
        <link href="{{ asset('/public/css/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
        <link href="{{ asset('/public/css/admin/admin.css') }}" rel="stylesheet">
        <link href="{{ asset('/public/css/admin/skins/skins.css') }}" rel="stylesheet">
        <link href="{{ asset('/public/css/admin/developer.css') }}" rel="stylesheet">

        <script src="{{ asset('/public/js/jquery.min.js') }}"></script>
        <script src="{{ asset('/public/js/admin/bootstrap.min.js') }}"></script>
        <script src="{{ asset('/public/js/admin/adminlte.min.js') }}"></script>
    </head>
    
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="wrapper">
            @include('flash_message')
            
            @yield('content')
        </div>
    </body>
</html>