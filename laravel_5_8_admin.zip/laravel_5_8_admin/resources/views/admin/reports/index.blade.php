@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="col-lg-12 searchBox boxShadow">
                                {{ Form::open(array('method'=>'get', 'id' => 'reportForm')) }}                                    
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <div class='input-group date' id='start_date'>
                                                {{ Form::text('start_date', app('request')->input('start_date'), array('placeholder'=>'Start Date', 'class'=>'form-control required', 'readonly'=>'readonly')) }} 
                                                <span class="input-group-addon">
                                                    <span class="fa fa-calendar"></span>
                                                </span>
                                            </div>                                                                               
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <div class='input-group date' id='end_date'>
                                                {{ Form::text('end_date', app('request')->input('end_date'), array('placeholder'=>'End Date', 'class'=>'form-control', 'readonly'=>'readonly')) }} 
                                                <span class="input-group-addon">
                                                    <span class="fa fa-calendar"></span>
                                                </span>
                                            </div>                                        
                                        </div>
                                    </div>

                                    <div class="col-md-2">
                                        <div class="form-group">
                                            {{ Form::Select('report_type', ['' => '- Report For -', 'farmer' => 'Farmer', 'user'=> 'User', 'payment' => 'Payment'], app('request')->input('report_type'), ['class'=>'form-control required']) }}
                                        </div>
                                    </div>    

                                    <div class="col-md-4">
                                        <div class="form-group">
                                            {{ Form::submit('Generate Reports', ['class'=>'btn btn-primary']) }}
                                            <a href="{{ url('/admin/reports') }}" class="btn btn-default">Reset</a>
                                        </div>
                                    </div>						
                                {{ Form::close() }}
                            </div>	
                        </div>
                        
                        <div id="reportDiv">
                            @include('admin.elements.report')
                        </div>
                       
                    </div>
                </div>
            </div>
        </section>
    </div>

    @include('admin.elements.common.bootstrap_alert_model')
    
    {{ Html::style('/public/plugins/hierarchy-select/assets/pygments.css') }}
    {{ Html::style('/public/plugins/hierarchy-select/dist/hierarchy-select.min.css') }}

    {{ Html::script('/public/plugins/hierarchy-select/dist/hierarchy-select.min.js') }}

    {!! Html::script('/public/plugins/bootstrap-datetimepicker/src/js/moment-2.18.1.min.js'); !!}
    {!! Html::script('/public/plugins/bootstrap-datetimepicker/src/js/bootstrap-datetimepicker.js'); !!}
    {!! Html::style('/public/plugins/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css') !!}

    <script>
        $(document).ready(function () {
            $('#reportForm').validate();
        });

        $(document).ready(function () {
            $('#start_date, #end_date').datetimepicker({
                format: 'YYYY-MM-DD',
                maxDate: moment(),
                icons: {
                    time: "fa fa-clock-o",
                    date: "fa fa-calendar",
                    up: "fa fa-arrow-up",
                    down: "fa fa-arrow-down"
                },
                useCurrent: false,
                ignoreReadonly: true
            });
            
            $('#start_date').datetimepicker().on('dp.change', function (e) {
                var incrementDay = moment(new Date(e.date));
                
                $('#end_date').data('DateTimePicker').minDate(incrementDay);
                $(this).data("DateTimePicker").hide();

                dateDifference();
            });

            $('#end_date').datetimepicker().on('dp.change', function (e) {
                var decrementDay = moment(new Date(e.date));
                
                $('#start_date').data('DateTimePicker').maxDate(decrementDay);
                $(this).data("DateTimePicker").hide();

                dateDifference();
            });
        });

        function dateDifference()
        {
            var startDate = $('#start_date').data("DateTimePicker").date();
            var endDate = $('#end_date').data("DateTimePicker").date();
            var timeDiff = 0;

            if(endDate)
            {
                timeDiff = (endDate - startDate) / 1000;
            }

            var dateDiff = Math.floor(timeDiff / (60 * 60 * 24));

            if(dateDiff < 0)
            {
                alertModel("{{ __('messages.Js.EndDateShouldGreaterOrEqual') }}");

                return false;
            }

            return true;
        }
    </script>
@endsection