@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="col-lg-12 searchBox showhidesearch boxShadow">
                                
                                {{ Form::open(array('method'=>'get')) }}
                                    <div class="col-lg-3">                                        
                                        {{ Form::text('search', app('request')->input('search'), ['placeholder'=>'Email or Name', 'class'=>'form-control']) }}					
                                    </div>

                                    <div class="col-lg-4">	
                                        {{ Form::submit('Search', ['class'=>'btn btn-primary']) }}
                                        <a href="{{ url('/admin/users') }}" class="btn btn-default">Reset</a>
                                    </div>						
                                {{ Form::close() }}
                            </div>	
                        </div>
                    
                        <div class="box-body">                            
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>@sortablelink('id', "ID")</th>
                                        <th>@sortablelink('fullname', 'Full Name')</th>                                        
                                        <th>Contact Number</th>
                                        <th>@sortablelink('email')</th>
                                        <th>Joined Date</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    @if(count($users))
                                        @php
                                            $statusClasses = ['Active' => 'label-success', 'Inactive' => 'label-danger'];
                                            $changeStatusTo = ['Active' => 'Deactivate', 'Inactive' => 'Activate'];
                                        @endphp

                                        @foreach($users as $user)
                                            <tr>
                                                <td>{{ $user->id }}</td>
                                                <td>{{ !empty($user->fullname) ? $user->fullname : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ !empty($user->contact_number) ? $user->contact_number : \Config::get('constants.EmptyNotation') }}</td>                                                
                                                <td title="{{ $user->email }}">{{ !empty($user->email) ? str_limit($user->email, $limit = 25, $end = '...') : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ $user->created_at }}</td>
                                                <td data="{{ \Crypt::encryptString($user->id) }}" model="{{ \Crypt::encryptString('users')}}" class="change-status-confirm {{ $user->status }}" title="Change Status"><span class="label {{ $statusClasses[$user->status] }}" id="status-{{ $user->id }}">{{ $user->status }}</span></td>
                                                <td class="action-btn">

                                                    {{ Form::open(['method'=>'GET', 'route'=>['users.edit', \Crypt::encryptString($user->id)]]) }}
                                                        {{ Form::button('', array('type'=>'submit', 'class'=>'pull-left fa fa-edit text-success', 'title'=>'Edit User')) }}
                                                    {{ Form::close() }}

                                                    {!! Form::open(['method' => 'GET', 'route' => ['users.show', \Crypt::encryptString($user->id)]]) !!}
                                                    {!! Form::button('', array('type' => 'submit', 'class' => 'pull-left fa fa-eye text-primary', 'title' => 'View User')) !!}
                                                    {!! Form::close() !!}

                                                    {{ Form::open(['method'=>'DELETE', 'route'=>['users.destroy', \Crypt::encryptString($user->id)]]) }}
                                                        {{ Form::button('', array('type'=>'submit', 'class'=>'delete-confirm pull-left fa fa-trash text-danger', 'title'=>'Delete User')) }}
                                                    {{ Form::close() }} 

                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr><td colspan="8" class="error-msg">{{ __('messages.NotFound.User') }}</td></tr>
                                    @endif
                                </tbody>
                            </table>
                            
                            @if(count($users))    
                                <div class="col-lg-12">
                                    <div class="pagination"> 
                                        {!! $users->appends($_GET)->links() !!} 
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    @include('admin.elements.js.common')

@endsection