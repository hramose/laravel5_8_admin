@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">{{ $subTitle }}</h3>
                        </div>                                                
                            
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <tbody>
                                    <tr>
                                        <td>Image</td>
                                        <td>
                                            @if(!empty($user->image) && Storage::disk('public')->has('users/' . $user->image))                                                        
                                                <a href="{{ asset('storage/app/public/users/' . $user->image) }}" class="gallery_popup" data-fancybox-group="gallery">
                                                    {{ Html::image(Storage::url('app/public/users/' . $user->image), 'image', ['class'=>'img_prvew img_prvew_height', 'title'=>'Image Preview']) }}
                                                </a>
                                            @else
                                                <a href="{{ asset(\Config::get('constants.NoImage50Icon')) }}" class="gallery_popup" data-fancybox-group="gallery">
                                                    {{ Html::image(asset(\Config::get('constants.NoImageIcon')), 'image', ['class'=>'img_prvew', 'title'=>'Image Preview']) }} 
                                                </a>
                                            @endif
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>Username</td>
                                        <td>{{ !empty($user->username) ? $user->username : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td>First Name</td>
                                        <td>{{ !empty($user->first_name) ? $user->first_name : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Last Name</td>
                                        <td>{{ !empty($user->last_name) ? ucwords($user->last_name) : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Email</td>
                                        <td>{{ !empty($user->email) ? $user->email : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Contact Number</td>
                                        <td>{{ !empty($user->contact_number) ? $user->contact_number : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Country</td>
                                        <td>{{ !empty($user->Country->name) ? $user->Country->name : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>

                                    <tr>
                                        <td>State</td>
                                        <td>{{ !empty($user->State->name) ? $user->State->name : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>

                                    <tr>
                                        <td>City</td>
                                        <td>{{ !empty($user->City->name) ? $user->City->name : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Status</td>
                                        <td>{{ !empty($user->status) ? $user->status : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Joinded Date</td>
                                        <td>{{ !empty($user->created_at) ? $user->created_at : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    @include('admin.elements.js.fancybox')
@endsection