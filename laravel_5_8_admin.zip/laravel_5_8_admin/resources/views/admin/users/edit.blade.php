@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">{{ $subTitle }}</h3>
                        </div>
                        
                        @if(!empty($user))
                            {{ Form::model($user, array('route'=>array('users.update', \Crypt::encryptString($user->id)), 'method'=>'PUT', 'files'=>true, 'id'=>'userForm')) }}
                        @else
                            {{ Form::open(array('url'=>'/admin/users', 'id'=>'userForm', 'files'=>true)) }}
                        @endif
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>First Name</label>
                                            {{ Form::text('first_name', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191')) }}
                                        </div>
                                    </div>
                                    
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Last Name</label>
                                            {{ Form::text('last_name', null, array('class'=>'form-control required', 'minlength'=>'2', 'maxlength'=>'191')) }}
                                        </div>
                                    </div>                                    
                                </div>
                                
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Username</label>
                                            {{ Form::text('username', null, array('class'=>'form-control required')) }}
                                        </div>
                                    </div>                              

                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Email Address</label>
                                            {{ Form::text('email', null, array('class'=>'form-control required email', 'id'=>'emailId', 'maxlength'=>'191')) }}
                                        </div>
                                    </div> 
                                </div>
                                
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Contact Number (Optional)</label>
                                            {{ Form::text('contact_number', null, array('class'=>'form-control phoneUS', 'minlength'=>'8', 'maxlength'=>'20')) }} 
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>Country</label>
                                            {{ Form::select('country_id', $countryList, null, ['class' => 'form-control required', 'id' => 'country-select', 'readonly']) }}
                                        </div>
                                    </div>
                                </div>

                                @php
                                    $cityDisabled = true;
                                                                        
                                    if(!empty($user->state_id)){
                                        $cityDisabled = false;
                                    }
                                @endphp

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>State <small>(Optional)</small></label>
                                            <div class="state-lists">
                                                {{ Form::select('state_id', $stateList, null, ['placeholder' => '- select -', 'class' => 'form-control', 'id' => 'state-list']) }}
                                            </div>
                                        </div> 
                                    </div>
                                    
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label>City <small>(Optional)</small></label>
                                            <div class="city-lists">
                                                {{ Form::select('city_id', $cityList, null, ['placeholder' => '- select -', 'class' => 'form-control', 'id' => 'city-list', 'disabled' => $cityDisabled, 'autocomplete' => 'off']) }}
                                            </div>
                                        </div>  
                                    </div> 
                                </div> 
                                
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <label>Status</label>
                                            {{ Form::Select('status', $status, null, ['placeholder'=>' - select - ', 'class'=>'form-control required']) }}
                                        </div>
                                    </div>

                                    <div class="col-lg-3">
                                        <label>Image <small>(Optional)</small></label>
                                        
                                        <div class="image-upload">
                                            <div class="file-label text-center">Browse...</div>
                                            {{ Form::file('image', ['id'=>'image']) }}
                                        </div>

                                        <span class="img-error error"></span>
                                    </div>
                                    
                                    <div class="col-lg-3">
                                        @if(!empty($user->image) && Storage::disk('public')->exists('users/' . $user->image))
                                            <i class="fa fa-remove delete-image"></i>

                                            <a href="{{ asset('storage/app/public/users/' . $user->image) }}" class="gallery_popup" data-fancybox-group="gallery">
                                                {{ Html::image(Storage::url('app/public/users/' . $user->image), 'image', array('id'=>'imagePreview', 'title'=>'Image Preview', 'class'=>'img_prvew img_prvew_height')) }}
                                            </a>
                                            
                                            {{ Form::hidden('delete_image', null, ['id'=>'deleteImage']) }}
                                        @else
                                            <i class="fa fa-remove delete-image" style="display:none;"></i>

                                            <a href="{{ asset(\Config::get('constants.NoImageIcon')) }}" class="gallery_popup" data-fancybox-group="gallery">
                                                {{ Html::image(asset(\Config::get('constants.NoImageIcon')), 'image', array('id'=>'imagePreview', 'title'=>'Image Preview', 'class'=>'img_prvew img_prvew_height')) }}
                                            </a>
                                        @endif 
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-lg-2  col-md-4">
                                        {{ Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat')) }}
                                    </div>
                                </div>
                            </div>    
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </section>
    </div>

    @include('admin.elements.js.custom_validation')
    @include('admin.elements.js.image')    
    @include('admin.elements.js.fancybox')

    {{ Html::style('/public/plugins/select2/css/select2.min.css') }}    
    {{ Html::script('/public/plugins/select2/js/select2.min.js') }}
    
    <script>
        $(document).ready(function(){            
            $('#userForm').validate({
                rules: {
                    username: {
                        required: true,
                        remote: {
                            url: APP_URL + "/admin/check-username-availability",
                            type: "post",
                            data: {
                                _token: _token,
                                username: $("input[username='username']").val(),
                                userId: "{{ \Crypt::encryptString($user->id) }}"
                            }
                        }
                    },

                    email: {
                        required: true,
                        remote: {
                            url: APP_URL + "/admin/check-email-availability",
                            type: "post",
                            data: {
                                _token: _token,
                                email: $("input[email='email']").val(),
                                userId: "{{ \Crypt::encryptString($user->id) }}",
                                roleId: "{{ \Crypt::encryptString($user->role_id) }}"
                            }
                        }
                    }
                },
                messages: {
                    username: {
                        required: 'Username is required.',
                        remote: 'Username already taken.'
                    },
                    email: {
                        required: 'Email is required.',
                        email: 'Please enter a valid email address.',
                        remote: 'Email already taken.'
                    }
                },
                submitHandler: function(form, submitFlag) {
                    var submitFlag = true;

                    if($('.img-error').html() !='')
                    {						
                        submitFlag = false;
                    }                                        
                    else
                    {
                        $('.img-error').html();
                    }

                    if(submitFlag) 
                        form.submit();
                }   
            });

            $('#state-list').select2();

            $('#city-list').select2();

            $('#state-list').on('change', function (e) {
                var selectedStateId = $(this).val();

                if (selectedStateId != "" && selectedStateId != 'undefined') {
                    $.ajax({
                        type: "POST",
                        beforeSend: function () {
                            //$('.ajax-loader').css("visibility", "visible");
                        },
                        url: APP_URL + "/admin/get-city-list-by-state",
                        data: {
                            _token: _token,
                            stateId: selectedStateId
                        },
                        success: function (response) {
                            if (response.success) {
                                if ($("#city-list").attr('disabled')) {
                                    $("#city-list").prop('disabled', false);
                                }

                                if ($('#city-list').data('select2')) {
                                    $("#city-list").select2("destroy").empty();
                                }

                                $("#city-list").select2({ data: response.data});
                            }
                        },
                        complete: function () {
                            //$('.ajax-loader').css("visibility", "hidden");
                        }
                    });
                }
            });
        });
    </script>
@endsection