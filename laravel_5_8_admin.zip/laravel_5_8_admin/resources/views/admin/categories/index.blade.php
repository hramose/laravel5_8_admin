@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="col-lg-12 searchBox showhidesearch boxShadow">
                                {{ Form::open(array('method'=>'get')) }}
                                    <div class="col-lg-4">                                        
                                        {{ Form::text('search', app('request')->input('search'), ['placeholder'=>'Name', 'class'=>'form-control']) }}					
                                    </div>

                                    <div class="col-lg-4">	
                                        {{ Form::submit('Submit', ['class'=>'btn btn-primary']) }}
                                        <a href="{{ url('/admin/categories') }}" class="btn btn-default">Reset</a>
                                    </div>						
                                {{ Form::close() }}
                                
                                <div class="col-lg-4 pull-right">
                                    <a href="{{ url('/admin/categories/create') }}" class="btn btn-primary pull-right addButton">Create Category</a>
                                </div>
                            </div>	
                        </div>

                        <div class="box-body">
                            <table class="table">                                
                                <thead>
                                    <tr>
                                        <th>@sortablelink('id', 'ID')</th>
                                        <th>@sortablelink('name', 'Name')</th>
                                        <th>@sortablelink('status')</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                
                                <tbody>
                                    @if(count($categoryList))
                                        @php
                                            $statusClasses = ['Active' => 'label-success', 'Inactive' => 'label-danger'];
                                            $changeStatusTo = ['Active' => 'Deactivate', 'Inactive' => 'Activate'];
                                        @endphp
                                        
                                        @foreach($categoryList as $category)
                                            <tr>
                                                <td>{{ !empty($category->id) ? $category->id : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ !empty($category->name) ? $category->name : \Config::get('constants.EmptyNotation') }}</td>
                                                <td data="{{ \Crypt::encryptString($category->id) }}" model="{{ \Crypt::encryptString('categories')}}" class="change-status-confirm {{ $category->status }}" title="Change Status"><span class="label {{ $statusClasses[$category->status] }}" id="status-{{ $category->id }}">{{ $category->status }}</span></td>
                                                <td class="action-btn">
                                                
                                                    {{ Form::open(['method'=>'GET', 'route'=>['categories.edit', \Crypt::encryptString($category->id)]]) }}
                                                        {{ Form::button('', array('type'=>'submit', 'class'=>'fa fa-edit text-success', 'title'=>'Edit Category')) }}
                                                    {{ Form::close() }}
                                                    
                                                    {{ Form::open(['method'=>'DELETE', 'route'=>['categories.destroy', \Crypt::encryptString($category->id)]]) }}
                                                        {{ Form::button('', array('type'=>'submit', 'class'=>'delete-confirm fa fa-trash text-danger', 'title'=>'Delete Category')) }}
                                                    {{ Form::close() }}
                                                    
                                                </td>
                                            </tr>
                                        @endforeach                                
                                    @else
                                        <tr><td colspan="5" class="error-msg">{{ __('messages.NotFound.Category') }}</td></tr>
                                    @endif
                                </tbody>
                            </table>
                            
                            @if(count($categoryList))    
                                <div class="col-lg-12">
                                    <div class="pagination">{!! $categoryList->appends($_GET)->links() !!}</div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
    
    @include('admin.elements.js.common')
@endsection