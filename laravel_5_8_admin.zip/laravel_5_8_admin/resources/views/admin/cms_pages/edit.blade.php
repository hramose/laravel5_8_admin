@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">
                                {{ $subTitle }}
                            </h3>
                        </div>						
                        
                        @if(!empty($cmsPage))
                            {!! Form::model($cmsPage, array('route'=>array('cms-pages.update', \Crypt::encryptString($cmsPage->id)), 'id'=>'cmsPageForm', 'method'=>'PUT')) !!}
                        @else
                            {{ Form::open(array('url'=>'/admin/cms-pages', 'id'=>'cmsPageForm')) }}
                        @endif
                            <div class="box-body">    
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                        @php
                                            $readOnly = !empty($cmsPage) && is_object($cmsPage) && !empty($cmsPage->is_readonly) && isset($cmsPage->is_readonly) && ($cmsPage->is_readonly == 'Yes') ? 'readonly' : '';
                                        @endphp

                                            {{ Form::label('title') }}
                                            {{ Form::text('title', null, ['class'=>'form-control required', 'minlength'=>'5', 'maxlength'=>'191', $readOnly]) }}
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            {!! Form::label('meta_key') !!} <small>(Optional)</small>
                                            {{ Form::text('meta_key', null, ['class'=>'form-control', 'minlength'=>'5', 'maxlength'=>'191']) }}
                                        </div>
                                    </div>
                                    
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            {!! Form::label('meta_description') !!} <small>(Optional)</small>
                                            {{ Form::text('meta_description', null, ['class'=>'form-control', 'minlength'=>'1', 'maxlength'=>'191']) }}
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="form-group ">
                                            {!! Form::label('description') !!}
                                            {{ Form::textarea('description', null, ['id'=>'description', 'class'=>'form-control required', 'minlength'=>'5']) }}
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-lg-2  col-md-4">
                                        {{ Form::submit('Submit', ['class'=>'btn btn-primary btn-block btn-flat']) }}
                                    </div>
                                    
                                    <div class="col-lg-2  col-md-4">
                                        {{ Form::reset('Reset', ['class' => 'btn btn-block btn-default']) }}
                                    </div>
                                </div>
                            </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </section>
    </div>

    {!! Html::script('/public/plugins/template-editor/ckeditor-4-full/ckeditor.js'); !!}	

    <script>
        $(document).ready(function () {
            CKEDITOR.replace('description');

            $("#cmsPageForm").validate({
                ignore: [],
                debug: false,
                rules: {
                    description: {
                        required: function(textarea) {
                            CKEDITOR.instances[textarea.id].updateElement(); // update textarea
                            
                            var editorcontent = textarea.value.replace(/<[^>]*>/gi, ''); // strip tags
                            
                            return editorcontent.length === 0;
                        }
                    }
                },
                messages: {
                    description: {
                        required: "{{ __('messages.Js.FieldRequired') }}"
                    }
                },
                /* use below section if required to place the error*/
                errorPlacement: function(error, element) 
                {
                    if (element.attr("name") == "description") 
                    {
                        error.insertBefore("textarea#description");
                    } else {
                        error.insertBefore(element);
                    }
                }
            });
        });
    </script>
@endsection