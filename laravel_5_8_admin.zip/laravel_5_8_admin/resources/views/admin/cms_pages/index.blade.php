@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">	
        <section class="content-header">
            <h1>
                {{ $subTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="col-lg-12 searchBox showhidesearch boxShadow">
                                {{ Form::open(array('method'=>'get')) }}
                                    <div class="col-lg-4">                                        
                                        {{ Form::text('search', app('request')->input('search'), ['placeholder'=>'Title', 'class'=>'form-control']) }}					
                                    </div>

                                    <div class="col-lg-4">	
                                        {{ Form::submit('Search', ['class'=>'btn btn-primary']) }}
                                        <a href="{{ url('/admin/cms-pages') }}" class="btn btn-default">Reset</a>
                                    </div>						
                                {{ Form::close() }}
                                
                                <div class="col-lg-4">	
                                    <a href="{{ url('/admin/cms-pages/create') }}" class="btn btn-primary pull-right addButton">Create CMS</a>
                                </div>		
                            </div>	
                        </div>

                        <div class="box-body">
                            <table class="table">
                                <thead>                      
                                    <tr>
                                        <th>@sortablelink('title')</th>
                                        <th>Slug</th>
                                        <th>Description</th>
                                        <th>@sortablelink('status')</th>
                                        <th class="action-col2">Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    @if(!empty($cmsPages) && is_object($cmsPages) && count($cmsPages))
                                        @php
                                            $statusClasses = ['Active' => 'label-success', 'Inactive' => 'label-danger'];
                                            //$statusTextClasses = ['Active' => 'text-success', 'Inactive' => 'text-danger'];
                                            $changeStatusTo = ['Active' => 'Deactivate', 'Inactive' => 'Activate'];
                                        @endphp
                                        
                                        @foreach($cmsPages as $cmsPage)
                                            <tr>
                                                <td>{{ !empty($cmsPage->title) ? $cmsPage->title : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ !empty($cmsPage->slug) ? $cmsPage->slug : \Config::get('constants.EmptyNotation') }}</td>
                                                <td>{{ (!empty($cmsPage->description)) ? (strlen($cmsPage->description) > 50 ? str_limit($cmsPage->description, 50) : $cmsPage->description) : \Config::get('constants.EmptyNotation') }}</td>
                                                <td data="{{ \Crypt::encryptString($cmsPage->id) }}" model="{{ \Crypt::encryptString('cms_pages')}}" class="change-status-confirm {{ $cmsPage->status }}" title="Change Status"><span class="label {{ $statusClasses[$cmsPage->status] }}" id="status-{{ $cmsPage->id }}">{{ $cmsPage->status }}</span></td>
                                                <td class="action-btn">										 
                                                    {{ Form::open(['method'=>'GET', 'route'=>['cms-pages.edit', \Crypt::encryptString($cmsPage->id)]]) }}
                                                        {{ Form::button('', array('type'=>'submit', 'class'=>'fa fa-edit text-success', 'title'=>'Edit CMS')) }}
                                                    {{ Form::close() }}
                                                    
                                                    @if(!empty($cmsPage->is_readonly) && $cmsPage->is_readonly == 'No')
                                                        &nbsp;|&nbsp;
                                                        {{ Form::open(['method' => 'DELETE', 'route' => ['cms-pages.destroy', \Crypt::encryptString($cmsPage->id)]]) }}
                                                            {{ Form::button('Delete', array('type' => 'submit', 'class' => 'delete-confirm pull-left text-danger', 'title' => 'Delete CMS')) }}
                                                        {{ Form::close() }}
                                                    @endif
                                                </td>
                                            </tr>
                                        @endforeach
                                    @else
                                        <tr><td colspan="5" class="error-msg">{{ __('messages.NotFound.Cms') }}</td></tr>
                                    @endif                                     
                                </tbody>
                            </table>
                            
                            @if(count($cmsPages))    
                                <div class="col-lg-12">
                                    <div class="pagination">{!! $cmsPages->appends(request()->query())->links() !!}</div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    @include('admin.elements.js.common')    
@endsection