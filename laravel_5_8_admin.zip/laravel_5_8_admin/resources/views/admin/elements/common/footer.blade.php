<footer class="main-footer">
    <div class="pull-right hidden-xs"></div>
    &copy; {{ date('Y') }} <strong>{{ config('SiteName') }}.</strong> All rights reserved.
</footer>
