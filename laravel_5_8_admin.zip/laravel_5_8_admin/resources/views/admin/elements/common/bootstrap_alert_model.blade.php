<div class="modal fade in" id="bootstrapAlertModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <!--<div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
                
                <h4 class="modal-title">Success Modal</h4>
            </div>-->
            
            <div class="modal-body" style="text-align:center;">
                <p></p>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
    function alertModel(msg, type = '')
    {
        var bootstrapModal = $('#bootstrapAlertModal');
        
        if(bootstrapModal.filter('.modal-success, .modal-danger')) {
            bootstrapModal.removeClass('modal-success modal-danger');
        }
        
        if(bootstrapModal.find('.modal-footer .btn').filter('.btn-outline, .btn-default')) {
            bootstrapModal.find('.modal-footer .btn').removeClass('btn-outline btn-default');
        }
        
        if(type == 'success')
        {
           bootstrapModal.addClass('modal-success');
           bootstrapModal.find('.modal-footer .btn').addClass('btn-outline');
        }
        else if(type == 'error')
        {
           bootstrapModal.addClass('modal-danger');
           bootstrapModal.find('.modal-footer .btn').addClass('btn-outline');
        }
        else
        {
            bootstrapModal.find('.modal-footer .btn').addClass('btn-default');
        }
        
        bootstrapModal.find('.modal-body p').text(msg);
        bootstrapModal.modal('show');
    }
</script>