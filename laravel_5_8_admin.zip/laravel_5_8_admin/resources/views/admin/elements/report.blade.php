<div class="box-body">
<div class="table-responsive">
@if(!empty(app('request')->input('report_type')) && (app('request')->input('report_type') == 'farmer' || app('request')->input('report_type') == 'user'))
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Full Name</th>
            <th>Username</th>
            <th>Email</th>
            <th>Registered On</th>
            <th>Status</th>
        </tr>
    </thead>

    <tbody>

        @if(!empty($dataList) && is_object($dataList) && count($dataList) > 0)

            @php
                $farmerOrUserCount = 0;
            @endphp
            @foreach($dataList as $data)
                <tr>
                    <td>
                        <a href="{{ route('farmers.show', \Crypt::encryptString($data->id)) }}" title='View Farmer'>
                            {{ $data->id }}
                        </a>
                    </td>
                    <td>{{ !empty($data->fullname) ? $data->fullname : \Config::get('constants.EmptyNotation') }}</td>
                    <td>{{ !empty($data->username) ? $data->username : \Config::get('constants.EmptyNotation') }}</td>
                    <td>{{ !empty($data->email) ? $data->email : \Config::get('constants.EmptyNotation') }}</td>
                    <td>{{ $data->created_at }}</td>
                    <td>
                        @php
                            $statusClasses = ['Active' => 'label-success', 'Inactive' => 'label-danger'];
                        @endphp
                        
                        <span class="label {{ $statusClasses[$data->status] }}">
                            {{ ucwords(str_replace('-', ' ', $data->status)) }}
                        </span>
                    </td>
                </tr>
                @php
                $farmerOrUserCount++;
                @endphp
            @endforeach
            
        @else
            @if(!empty(app('request')->input('report_type')) && app('request')->input('report_type') == 'farmer')
            <tr><td colspan="6" class="error-msg">{{ __('messages.NotFound.Farmer') }}</td></tr>
            @elseif(!empty(app('request')->input('report_type')) && app('request')->input('report_type') == 'user')
            <tr><td colspan="6" class="error-msg">{{ __('messages.NotFound.User') }}</td></tr>
            @endif
        @endif
                                            
    </tbody>
</table>

@elseif(!empty(app('request')->input('report_type')) && (app('request')->input('report_type') == 'payment'))

<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Farmer Name</th>
            <th>Price</th>
            <th>Transaction ID</th>
            <th>Date Time</th>
            <th>Status</th>
        </tr>
    </thead>

    <tbody>
    @if(!empty($paymentList) && is_object($paymentList) && count($paymentList) > 0)
    @php
        $statusClasses = ['Approve' => 'label-success', 'Reject' => 'label-danger', 'Pending' => 'label-primary'];
        $changeStatusTo = ['Pending' => 'Approve', 'Approve' => 'Reject', 'Reject' => 'Approve'];
        $total = 0;
            
    @endphp

    @foreach($paymentList as $payment)

    <tr>
        <td>
            <a href="{{ route('payments.show', \Crypt::encryptString($payment->id)) }}" title='View Payment'>
                {{ !empty($payment->id) ? $payment->id : \Config::get('constants.EmptyNotation') }}
            </a>
        </td>
        <td>{{ !empty($payment->User->full_name) ? $payment->User->full_name : \Config::get('constants.EmptyNotation') }}</td>
        <td>{{ !empty($payment->pay_amount) ? $payment->pay_amount : \Config::get('constants.EmptyNotation') }}</td>
        <td>{{ !empty($payment->transaction_id) ? $payment->transaction_id : \Config::get('constants.EmptyNotation') }}</td>
        <td>{{ $payment->created_at }}</td>
        <td>
            @php
                $statusClasses = ['Complete' => 'label-success', 'Failed' => 'label-danger', 'Pending' => 'label-primary'];
            @endphp
            
            <span class="label {{ $statusClasses[$payment->status] }}">
                {{ ucwords(str_replace('-', ' ', $payment->status)) }}
            </span>
        </td>
    </tr>

        @php
        $total = $total+$payment->pay_amount;
        @endphp

    @endforeach

    @else
        <tr><td colspan="6" class="error-msg">{{ __('messages.NotFound.Payment') }}</td></tr>
    @endif
                                            
    </tbody>
</table>

@else
    <center><span colspan="6" class="error-msg">{{ __('messages.NotFound.ReportType') }}</span></center>
@endif
</div>
</div>


<div class="box-footer clearfix">

<div class="col-md-9">

@if(!empty(app('request')->input('report_type')) && (app('request')->input('report_type') == 'farmer' || app('request')->input('report_type') == 'user') && !empty($dataList) && count($dataList) > 0)    
<div class="pagination"> 
    {!! $dataList->appends($_GET)->links() !!} 
</div>
@elseif(!empty($paymentList) && count($paymentList) > 0)
<div class="pagination"> 
    {!! $paymentList->appends($_GET)->links() !!} 
</div>
@endif
</div>

 <div class="col-md-3">
@if(!empty($farmerOrUserCount))
<label class="btn-sm btn-primary pull-right"><b>{{!empty($label) ? $label : ''}}:</b> {{ !empty($farmerOrUserCount) ? $farmerOrUserCount : '' }}</label>
@elseif(!empty($total))
<label class="btn-sm btn-primary pull-right"><b>Total Revenue Generated: </b> {{ !empty($total) ? $total : '' }}</label>
@endif
</div>

</div>

<style>ul.pagination{margin: auto !important;}</style>



