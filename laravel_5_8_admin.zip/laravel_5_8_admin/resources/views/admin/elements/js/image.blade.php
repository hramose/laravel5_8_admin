<script>
    $("#image").change(function(){
        var uploadeImageSizeKb = this.files[0].size / 1024;
        var uploadeImageSizeMb = Math.round((uploadeImageSizeKb / 1024) * 100) / 100;
        
        var maxImageSizeKb = parseInt("{{ \Config::get('constants.ImageSize') }}");        
        var maxImageSizeMb = Math.round((maxImageSizeKb / 1024) * 100) / 100;
        
        var allowedImageExtensions = ['jpeg', 'jpg', 'png'];
        var uploadeImageExtension = this.files[0]['name'].replace(/^.*\./, '').toLowerCase();
        
        
        if(uploadeImageSizeMb > maxImageSizeMb)
        {
            $('.img-error').html('Image size is greater than ' + maxImageSizeMb + ' MB.');
        }
        else if ($.inArray(uploadeImageExtension, allowedImageExtensions) === -1) 
        {
            $('.img-error').html("{{ __('messages.FileNotValid') }}");
        }
        else
        {			
            imagePreview(this);	
        }
    });

    function imagePreview(input)
    {
        $('.img-error').html('');
        
        if(input.files && input.files[0])
        {
            var reader = new FileReader();
    
            reader.onload = function (e) {
                $('#imagePreview').attr('src', e.target.result);
                $('#imagePreview').parent('.gallery_popup').attr('href', e.target.result);
                $('.delete-image').css('display', 'block');
            };
    
            reader.readAsDataURL(input.files[0]);
        }       
    }
    
    $(document).on("click", ".delete-image", function () {
        $("#deleteImage").attr('value', 'Yes');
        
        if($('#imagePreview').attr('src').indexOf('no_image.jpg') === -1)
        {
            $('#imagePreview').attr('src', "{{ asset(\Config::get('constants.NoImageIcon')) }}");
            $('#imagePreview').parent('.gallery_popup').attr('href', "{{ asset(\Config::get('constants.NoImageIcon')) }}");
            $('.delete-image').css('display', 'none');
            $('#image').val('');
        }
    });
</script>