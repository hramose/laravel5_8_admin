<script src="https://maps.googleapis.com/maps/api/js?key={{CommonHelper::fetchGlobalSettingValueByName('GooglePlacesApiKey')}}&libraries=places"></script>

<script>
    function initializeAutocomplete()
    {
        var input = document.getElementById('address');
        var options = {};
        var autocomplete = new google.maps.places.Autocomplete(input, options);

        google.maps.event.addListener(autocomplete, 'place_changed', function() {
            var place = autocomplete.getPlace();
            var lat = place.geometry.location.lat();
            var lng = place.geometry.location.lng();
            document.getElementById("latitude").value = lat;
            document.getElementById("longitude").value = lng;
        });
    }
</script>