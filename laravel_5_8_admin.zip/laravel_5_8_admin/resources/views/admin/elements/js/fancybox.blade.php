{!! Html::script('/public/plugins/fancybox/jquery.fancybox.js') !!}
{!! Html::style('/public/plugins/fancybox/jquery.fancybox.css') !!}

<script>
    $(document).ready(function () {
        $(".gallery_popup").fancybox({
            fitToView : true,
            loop: false,
            wrapCSS : 'popup_wrapp' // add a class selector to the fancybox wrap
        });
    });
</script>
