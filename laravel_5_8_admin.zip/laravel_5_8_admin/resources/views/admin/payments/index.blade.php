@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-xs-12">
                    <div class="box">
                        <div class="box-header with-border">
                            <div class="col-lg-12 searchBox showhidesearch boxShadow">
                                {{ Form::open(array('method'=>'get')) }}
                                    <div class="col-lg-4">                                        
                                        {{ Form::text('search', app('request')->input('search'), ['placeholder'=>'Transaction no', 'class'=>'form-control']) }}					
                                    </div>

                                    <div class="col-lg-4">	
                                        {{ Form::submit('Submit', ['class'=>'btn btn-primary']) }}
                                        <a href="{{ url('/admin/payments') }}" class="btn btn-default">Reset</a>
                                    </div>						
                                {{ Form::close() }}
                            </div>	
                        </div>
                    
                        <div class="box-body">
                            <table class="table">
                                <thead>
                                    <tr>
                                        <th>@sortablelink('transaction_id', 'Txn ID')</th>
                                        <th>@sortablelink('User.fullname', 'Farmer Name')</th>
                                        <th>@sortablelink('User.email', 'Farmer Email')</th>
                                        <th>@sortablelink('pay_amount', 'Amount')</th>
                                        <th>Subscription Plan</th>
                                        <th>@sortablelink('transaction_date_time','Date Time')</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    @if(count($payments))                                    

                                        @php
                                            $statusClasses = ['Complete' => 'label-success', 'Failed' => 'label-danger', 'Pending' => 'label-primary'];
                                        @endphp

                                        @foreach($payments as $payment)
                                            <tr>
                                                <td>
                                                    {{ !empty($payment->transaction_id) ? $payment->transaction_id : \Config::get('constants.EmptyNotation') }}
                                                </td>

                                                <td>
                                                @if(!empty($payment->User->fullname))
                                                    <a href="{{ route('farmers.show', \Crypt::encryptString($payment->User->id)) }}" title='View User'>
                                                            {{ $payment->User->fullname }}
                                                    </a>
                                                @else
                                                    {{ \Config::get('constants.EmptyNotation') }}
                                                @endif
                                                </td>

                                                <td title="{{ $payment->User->email }}">{{ !empty($payment->User->email) ? str_limit($payment->User->email, $limit = 25, $end = '...') : \Config::get('constants.EmptyNotation') }}</td>
                                                
                                                <td>{{ !empty($payment->pay_amount) ? CommonHelper::fetchGlobalSettingValueByName('CurrencySign') . $payment->pay_amount : \Config::get('constants.EmptyNotation') }}</td>

                                                <td>{{ !empty($payment->Subscription->type) ? $payment->Subscription->type : \Config::get('constants.EmptyNotation') }}</td>

                                                <td>{{ $payment->created_at }}</td>
                                                <td><span class="label {{ $statusClasses[$payment->status] }}" id="status-{{ $payment->id }}">{{ $payment->status }}</span></td>
                                                <td class="action-btn">
                                                    {{ Form::open(['method'=>'GET', 'route'=>['payments.show', \Crypt::encryptString($payment->id)]]) }}
                                                        {{ Form::button('', array('type'=>'submit', 'class'=>'fa fa-eye text-info', 'title'=>'View Payment Detail')) }}
                                                    {{ Form::close() }}
                                                </td>
                                            </tr>
                                        @endforeach                                    
                                    @else
                                        <tr><td colspan="8" class="error-msg">{{ __('messages.NotFound.Payment') }}</td></tr>
                                    @endif
                                </tbody>
                            </table>

                            @if(count($payments))    
                                <div class="col-sm-12">
                                    <div class="pagination"> 
                                        {!! $payments->appends($_GET)->links() !!} 
                                    </div>
                                </div>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection