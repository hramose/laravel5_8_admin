@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-lg-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">{{ $subTitle }}</h3>
                        </div>                                                
                            
                        <div class="box-body table-responsive no-padding">
                            <table class="table table-hover">
                                <tbody>
                                    <tr>
                                        <th>Transaction Id</th>
                                        <td>{{ !empty($transaction->transaction_id) ? $transaction->transaction_id : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <th>Date Time</th>
                                        <td>{{ !empty($transaction->transaction_date_time) ? $transaction->transaction_date_time : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <th>Farmer Name</th>
                                        <td>
                                        <a href="{{ route('farmers.show', \Crypt::encryptString($transaction->user_id)) }}" title='View Farmer'>
                                            {{ !empty($transaction->User) ? $transaction->User->fullname : \Config::get('constants.EmptyNotation') }}
                                        </a>
                                        </td>
                                    </tr>

                                    <tr>
                                        <th>Farmer Email</th>
                                        <td>{{ !empty($transaction->User->email) ? $transaction->User->email : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>

                                    <tr>
                                        <th>Subscription Plan</th>
                                        <td>{{ !empty($transaction->Subscription->type) ? $transaction->Subscription->type : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <th>Amount</th>
                                        <td>{{ !empty($transaction->pay_amount) ? CommonHelper::fetchGlobalSettingValueByName('CurrencySign') . $transaction->pay_amount : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <th>Status</th>
                                        <td>{{ !empty($transaction->status) ? ucwords($transaction->status) : \Config::get('constants.EmptyNotation') }}</td>
                                    </tr>
                                    
                                    <tr>
                                        <th>Transaction Details/Response</th>

                                        @if(!empty($transaction->transaction_response))
                                            <td style="width:75%;"><textarea disabled="" class="scroll-area2">{{ print_r(json_decode($transaction->transaction_response, true), 1) }}</textarea></td>
                                        @else
                                            <td>{{ \Config::get('constants.EmptyNotation') }}</td>
                                        @endif
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection