@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}        
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-6">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">{{ $subTitle }}</h3>
                        </div>
                        
                        {{ Form::open(array('method'=>'POST', 'id'=>'changePasswordForm')) }}
                            <div class="box-body">
                                <div class="form-group">
                                    <label>Current Password</label>
                                    {{ Form::password('current_password', array('class'=>'form-control required')) }}
                                </div>
                                
                                <div class="form-group">
                                    <label>New Password</label>
                                    {{ Form::password('password', array('class'=>'form-control required', 'id'=>'password', 'minlength'=>'8', 'maxlength'=>'15')) }}
                                </div>
                                
                                <div class="form-group">
                                    <label>Confirm New Password</label>
                                    {{ Form::password('password_confirmation', array('class'=>'form-control required', 'data-rule-equalTo'=>'#password')) }} 
                                </div>                            

                                <div class="form-group">
                                    {{ Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat')) }}
                                </div>
                            </div>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        $(document).ready(function () {
            $('#changePasswordForm').validate();
        });
    </script>
@endsection
