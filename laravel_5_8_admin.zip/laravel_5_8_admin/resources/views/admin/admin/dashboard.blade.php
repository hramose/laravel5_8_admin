@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content container-fluid">
            <div class="row">
                <div class="col-lg-3 col-xs-6">
                    <div class="small-box bg-aqua">
                        <div class="inner">
                            <h3>{{ $userCount }}</h3>
                            <p>Number Of Users</p>
                        </div>
                        
                        <div class="icon">
                            <i class="fa fa-users"></i>
                        </div>
                        
                        <a href="{{ url('/admin/users') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>

                <div class="col-lg-3 col-xs-6">
                    <div class="small-box bg-green">
                        <div class="inner">
                            <h3>{{ $farmerCount }}</h3>
                            <p>Number Of Farmers</p>
                        </div>
                        
                        <div class="icon">
                            <i class="fa fa-user-circle"></i>
                        </div>
                        
                        <a href="{{ url('/admin/farmers') }}" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                    </div>
                </div>
            </div>           
           
            <div class="row">
                <div class="col-lg-12 col-xs-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Recent Registered Users</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                            </div>
                        </div>
            
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table no-margin">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Full Name</th>
                                            <th>Username</th>
                                            <th>Email</th>
                                            <th>Registered On</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(!empty($latestUsers) && is_object($latestUsers) && count($latestUsers))
                                            @foreach($latestUsers as $user)
                                                <tr>
                                                    <td>
                                                        <a href="{{ route('users.show', \Crypt::encryptString($user->id)) }}" title='View User'>
                                                            {{ $user->id }}
                                                        </a>
                                                    </td>
                                                    <td>{{ !empty($user->fullname) ? $user->fullname : \Config::get('constants.EmptyNotation') }}</td>
                                                    <td>{{ !empty($user->username) ? $user->username : \Config::get('constants.EmptyNotation') }}</td>
                                                    <td title="{{ $user->email }}">{{ !empty($user->email) ? str_limit($user->email, $limit = 25, $end = '...') : \Config::get('constants.EmptyNotation') }}</td>
                                                    <td>{{ $user->created_at }}</td>
                                                    <td>
                                                        @php
                                                            $statusClasses = ['Active' => 'label-success', 'Inactive' => 'label-danger'];
                                                        @endphp
                                                        
                                                        <span class="label {{ $statusClasses[$user->status] }}">
                                                            {{ ucwords(str_replace('-', ' ', $user->status)) }}
                                                        </span>
                                                    </td>                                                    
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr><td colspan="6" class="error-msg">{{ __('messages.NotFound.User') }}</td></tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="box-footer clearfix">
                            <a href="{{ url('/admin/users') }}" class="btn btn-sm btn-default btn-flat pull-right">View All Users</a>
                        </div>

                    </div>
                </div>
            </div>
        
            <div class="row">
                <div class="col-lg-12 col-xs-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Recent Registered Farmers</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                            </div>
                        </div>
            
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table no-margin">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Full Name</th>
                                            <th>Username</th>
                                            <th>Email</th>
                                            <th>Registered On</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(count($latestFarmers) > 0)
                                            @foreach($latestFarmers as $farmer)
                                                <tr>
                                                    <td>
                                                        <a href="{{ route('farmers.show', \Crypt::encryptString($farmer->id)) }}" title='View Farmer'>
                                                            {{ $farmer->id }}
                                                        </a>
                                                    </td>
                                                    <td>{{ !empty($farmer->fullname) ? $farmer->fullname : \Config::get('constants.EmptyNotation') }}</td>
                                                    <td>{{ !empty($farmer->username) ? $farmer->username : \Config::get('constants.EmptyNotation') }}</td>
                                                    <td title="{{ $farmer->email }}">{{ !empty($farmer->email) ? str_limit($farmer->email, $limit = 25, $end = '...') : \Config::get('constants.EmptyNotation') }}</td>
                                                    <td>{{ $farmer->created_at }}</td>
                                                    <td>
                                                        @php
                                                            $statusClasses = ['Active' => 'label-success', 'Inactive' => 'label-danger'];
                                                        @endphp
                                                        
                                                        <span class="label {{ $statusClasses[$farmer->status] }}">
                                                            {{ ucwords(str_replace('-', ' ', $farmer->status)) }}
                                                        </span>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr><td colspan="6" class="error-msg">{{ __('messages.NotFound.Farmer') }}</td></tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="box-footer clearfix">
                            <a href="{{ url('/admin/farmers') }}" class="btn btn-sm btn-default btn-flat pull-right">View All Farmers</a>
                        </div>

                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12 col-xs-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Recent Payment</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                            </div>
                        </div>
            
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table no-margin">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Farmer Name</th>
                                            <th>Price</th>
                                            <th>Transaction ID</th>
                                            <th>Date Time</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(!empty($latestPayments) && is_object($latestPayments) && count($latestPayments) > 0)
                                            @foreach($latestPayments as $payment)
                                                <tr>
                                                    <td>
                                                        <a href="{{ route('payments.show', \Crypt::encryptString($payment->id)) }}" title='View Payment'>
                                                            {{ !empty($payment->id) ? $payment->id : '' }}
                                                        </a>
                                                    </td>
                                                    <td class="text-capitalize">
                                                        <a href="{{ route('farmers.show', \Crypt::encryptString($payment->user_id)) }}" title='View Farmer'>
                                                            {{ !empty($payment->User->full_name) ? $payment->User->full_name : '' }}
                                                        </a>
                                                    </td>
                                                    <td>{{ !empty($payment->pay_amount) ? CommonHelper::fetchGlobalSettingValueByName('CurrencySign') . $payment->pay_amount : '' }}</td>
                                                    <td>{{ !empty($payment->transaction_id) ? $payment->transaction_id : '' }}</td>
                                                    <td>{{ $payment->created_at }}</td>
                                                    <td>
                                                        @php
                                                            $statusClasses = ['Complete' => 'label-success', 'Failed' => 'label-danger', 'Pending' => 'label-primary'];
                                                        @endphp
                                                        
                                                        <span class="label {{ $statusClasses[$payment->status] }}">
                                                            {{ ucwords(str_replace('-', ' ', $payment->status)) }}
                                                        </span>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr><td colspan="6" class="error-msg">{{ __('messages.NotFound.Payment') }}</td></tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="box-footer clearfix">
                            <a href="{{ url('/admin/payments') }}" class="btn btn-sm btn-default btn-flat pull-right">View All Payments</a>
                        </div>

                    </div>
                </div>
            </div>

            <div class="row">
                <div class="col-lg-12 col-xs-12">
                    <div class="box box-info">
                        <div class="box-header with-border">
                            <h3 class="box-title">Recent Review by Users</h3>

                            <div class="box-tools pull-right">
                                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                            </div>
                        </div>
            
                        <div class="box-body">
                            <div class="table-responsive">
                                <table class="table no-margin">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>User Name</th>
                                            <th>Farmer Name</th>
                                            <th>Rating</th>
                                            <th>Date Time</th>
                                            <th>Status</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @if(!empty($latestReviews) && is_object($latestReviews) && count($latestReviews) > 0)
                                            @foreach($latestReviews as $review)
                                            <tr>
                                                    <td>
                                                        <a href="{{ route('reviews.show', \Crypt::encryptString($review->id)) }}" title='View Review'>
                                                            {{ !empty($review->id) ? $review->id : '' }}
                                                        </a>
                                                    </td>
                                                        
                                                    <td>
                                                        <a href="{{ route('users.show', \Crypt::encryptString($review->User->id)) }}" title='View User'>
                                                            {{ !empty($review->User->full_name) ? $review->User->full_name : '' }}
                                                        </a>            
                                                    </td>
                                                    <td>
                                                        <a href="{{ route('farmers.show', \Crypt::encryptString($review->Farmer->id)) }}" title='View Farmer'>
                                                            {{ !empty($review->Farmer->full_name) ? $review->Farmer->full_name : '' }}
                                                        </a>
                                                    </td>
                                                    <td>{{ !empty($review->rating) ? $review->rating : '' }}</td>
                                                    <td>{{ $review->created_at }}</td>
                                                    <td>
                                                        @php
                                                            $statusClasses = ['Approve' => 'label-success', 'Reject' => 'label-danger', 'Pending' => 'label-primary'];
                                                        @endphp
                                                        
                                                        <span class="label {{ $statusClasses[$review->status] }}">
                                                            {{ ucwords(str_replace('-', ' ', $review->status)) }}
                                                        </span>
                                                    </td>
                                                </tr>
                                            @endforeach
                                        @else
                                            <tr><td colspan="7" class="error-msg">{{ __('messages.NotFound.Review') }}</td></tr>
                                        @endif
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div class="box-footer clearfix">
                            <a href="{{ url('/admin/reviews') }}" class="btn btn-sm btn-default btn-flat pull-right">View All Review Ratings</a>
                        </div>

                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection
