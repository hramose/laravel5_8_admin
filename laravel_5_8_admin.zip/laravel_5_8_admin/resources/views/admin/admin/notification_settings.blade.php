@extends('admin.layout.admin_inner_page')

@section('content')
    <div class="content-wrapper">
        <section class="content-header">
            <h1>
                {{ $mainTitle }}       
            </h1>

            @include('admin.elements.common.breadcrumb')
        </section>

        <section class="content">
            <div class="row">
                <div class="col-md-12">
                    <div class="box box-primary">
                        <div class="box-header with-border">
                            <h3 class="box-title">{{ $subTitle }}</h3>
                        </div>
                        
                        {{ Form::model($notificationSetting, array('method'=>'POST', 'id'=>'notificationSettingsForm')) }}
                            <div class="box-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="checkbox">
                                            @php 
                                                $checked = false;
											
                                                if(Auth::user()->want_email_notification == 'Yes')
                                                    $checked = true;
                                            @endphp
                                            
                                            <label>
                                                {{ Form::checkbox('want_email_notification', 'Yes', $checked, ['class'=>'email-notification']) }}
                                                <span class="v-align-sub">Email Notification</span>
                                            </label>
                                        </div>
                                    </div>                             
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="checkbox">
                                            @php 
                                                $checked = false;
											
                                                if(!empty($notificationSetting) && $notificationSetting->want_profile_review_email == 'Yes')
                                                    $checked = true;
                                            @endphp
                                            
                                            <label>
                                                {{ Form::checkbox('want_profile_review_email', 'Yes', $checked, ['class'=>'notification-settings']) }}
                                                <span class="v-align-sub">Profile Review Email Notification</span>
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="checkbox">
                                            @php 
                                                $checked = false;
											
                                                if(!empty($notificationSetting) && $notificationSetting->want_rating_review_email == 'Yes')
                                                    $checked = true;
                                            @endphp
                                            
                                            <label>
                                                {{ Form::checkbox('want_rating_review_email', 'Yes', $checked, ['class'=>'notification-settings']) }}
                                                <span class="v-align-sub">Rating Review Email Notification</span>
                                            </label>
                                        </div>
                                    </div>
                                    
                                    <div class="col-md-4">
                                        <div class="checkbox">
                                            @php 
                                                $checked = false;
											
                                                if(!empty($notificationSetting) && $notificationSetting->want_payment_email == 'Yes')
                                                    $checked = true;
                                            @endphp
                                            
                                            <label>
                                                {{ Form::checkbox('want_payment_email', 'Yes', $checked, ['class'=>'notification-settings']) }}
                                                <span class="v-align-sub">Payment Email</span> 
                                            </label>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-lg-2 col-md-4">
                                        {{ Form::submit('Submit', array('class'=>'btn btn-primary btn-block btn-flat')) }}
                                    </div> 
                                </div>
                            </div>
                        {{ Form::close() }}                        
                    </div>
                </div>
            </div>
        </section>
    </div>

    <script>
        $(document).ready(function () {
            $('.email-notification').click(function(){
                if (!this.checked) {
                    $('.notification-settings').prop('checked', false);
                }
            });
            
            $('.notification-settings').click(function(){
                if($(".notification-settings:checked").length) {
                    $('.email-notification').prop('checked', true);
                }
            });
        });
    </script>
@endsection