/**
 * @license Copyright (c) 2003-2017, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */

CKEDITOR.editorConfig = function( config ) {
	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#AADC6E';

	config.allowedContent = true;
    
    config.filebrowserBrowseUrl = APP_URL+'/public/plugins/template-editor/kcfinder/browse.php?opener=ckeditor&type=files';

    config.filebrowserImageBrowseUrl = APP_URL+'/public/plugins/template-editor/kcfinder/browse.php?opener=ckeditor&type=images';

    config.filebrowserFlashBrowseUrl = APP_URL+'/public/plugins/template-editor/kcfinder/browse.php?opener=ckeditor&type=flash';

    config.filebrowserUploadUrl = APP_URL+'/public/plugins/template-editor/kcfinder/upload.php?opener=ckeditor&type=files';

    config.filebrowserImageUploadUrl = APP_URL+'/public/plugins/template-editor/kcfinder/upload.php?opener=ckeditor&type=images';

    config.filebrowserFlashUploadUrl = APP_URL+'/public/plugins/template-editor/kcfinder/upload.php?opener=ckeditor&type=flash';
};
