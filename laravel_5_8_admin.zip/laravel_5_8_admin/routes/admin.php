<?php

/*
|--------------------------------------------------------------------------
| Admin Routes
|--------------------------------------------------------------------------
|
| Here is where you can register admin routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "admin" middleware group. Now create something great!
|
*/
Route::get('access-denied', function () {
    return view('admin.access_denied');
});

Route::match(array('POST'), '/update_status', array(
    'uses' => 'Admin\BaseController@updateStatus',
    'as' => 'updateStatus'
));

Route::match(array('POST'), '/get-city-list-by-state', array(
    'uses' => 'Controller@getCityListByState'
));

Route::match(array('GET', 'POST'), 'check-username-availability', array(
    'uses' => 'Admin\BaseController@checkUsernameAvailability'
));

Route::match(array('GET', 'POST'), 'check-email-availability', array(
    'uses' => 'Admin\BaseController@checkEmailAvailability'
));

Route::match(array('GET', 'POST'), '/', array(
    'uses' => 'Admin\AdminController@login',
    'as' => 'login'
));

Route::match(array('GET', 'POST'), 'forgot-password', array(
    'uses' => 'Admin\AdminController@forgotPassword'
));

Route::match(array('GET', 'POST'), 'reset-password', array(
    'uses' => 'Admin\AdminController@resetPassword'
));

Route::match(array('GET', 'POST'), 'dashboard', array(
    'uses' => 'Admin\AdminController@dashboard'
));

Route::match(array('GET', 'POST'), 'logout', array(
    'uses' => 'Admin\AdminController@logout',
    'as' => 'logout'
));

Route::match(array('GET', 'POST'), 'notification-settings', array(
    'uses' => 'Admin\AdminController@notificationSettings',
    'as' => 'notificationSettings'
));

Route::match(array('GET', 'POST'), 'change-password', array(
    'uses' => 'Admin\AdminController@changePassword',
    'as' => 'changePassword'
));

Route::resource('users', 'Admin\UsersController');

Route::resource('farmers', 'Admin\FarmersController');

Route::match(array('POST'), '/update_verify_status', array(
    'uses' => 'Admin\FarmersController@updateVerifyStatus'
));

Route::resource('categories', 'Admin\CategoriesController');

Route::resource('reviews', 'Admin\RatingReviewsController');

Route::match(array('GET'), 'transaction/download-csv/{id}', array(
    'uses' => 'Admin\TransactionsController@downloadTransactionCsv'
))->name('downoad-csv-transaction');

Route::resource('reports', 'Admin\ReportsController');

Route::resource('subscriptions', 'Admin\SubscriptionsController');

Route::resource('payments', 'Admin\PaymentsController');

Route::match(array('GET', 'POST'), '/global-settings', array(
    'uses' => 'Admin\SiteSettingsController@globalSettings'    
));

Route::match(array('POST'), '/update-global-setting/{id}', array(
    'uses' => 'Admin\SiteSettingsController@updateGlobalSetting'    
));

Route::match(array('GET', 'POST'), '/smtp-settings', array(
    'uses' => 'Admin\SiteSettingsController@smtpSettings'    
));

Route::match(array('POST'), '/update-smtp-setting/{id}', array(
    'uses' => 'Admin\SiteSettingsController@updateSmtpSetting',
    'as' => 'update-smtp-setting'
));

Route::match(array('GET', 'POST'), '/mailing-addresses-settings', array(
    'uses' => 'Admin\SiteSettingsController@mailingAddressesSettings'    
));

Route::match(array('POST'), '/update-mailing-addresses-settings/{id}', array(
    'uses' => 'Admin\SiteSettingsController@updateMailingAddressesSettings',
    'as' => 'update-mailing-addresses-settings'
));

Route::resource('cms-pages', 'Admin\CmsPagesController');

Route::resource('email-templates', 'Admin\EmailTemplatesController');

Route::resource('events', 'Admin\EventsController')->only(['show']);