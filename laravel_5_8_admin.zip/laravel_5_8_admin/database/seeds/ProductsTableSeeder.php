<?php
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class ProductsTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        foreach (range(1, 10) as $index) {
            DB::table('products')->insert([
                'user_id' => 1,
                'farm_detail_id' => 1,
                'name' => $faker->name,
                'short_description' => $faker->text($maxNbChars = 25),
                'slug' => $faker->slug,
                'category_id' => 1,
                'price' => $faker->randomNumber(2),
                'created_at' => $faker->DateTime,
                
            ]);
        }
    }
}
