<?php
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class FarmDetailsTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        foreach (range(1, 10) as $index) {
            DB::table('farm_details')->insert([
                'user_id' => 1,
                'country_id' => 1,
                'state_id' => 1,
                'city_id' => 1,
                'name' => $faker->company,
                'short_description' => $faker->text($maxNbChars = 25),
                'farm_story' =>$faker->text,
                'address' => $faker->address,
                'zipcode' => $faker->postcode,
                'created_at' => $faker->DateTime
            ]);
        }
    }
}
