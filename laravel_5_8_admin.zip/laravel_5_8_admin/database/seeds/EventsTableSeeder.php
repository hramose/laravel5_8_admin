<?php
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class EventsTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        foreach (range(1, 10) as $index) {
            DB::table('events')->insert([
                'user_id' => 1,
                'farm_detail_id' => 1,
                'name' => $faker->name,
                'description' => $faker->text($maxNbChars = 25),
                'start_date_time' => $faker->DateTime,
                'end_date_time' => $faker->DateTime,
                'purpose' => $faker->name,
                'contact_email_id' => preg_replace('/@example\..*/', '@mailinator.com', $faker->unique()->safeEmail),
                'contact_number' => $faker->phoneNumber,
                'location' => $faker->city,
                'slug' => $faker->slug,
                'created_by' => 1,
                'created_at' => $faker->DateTime,
                
            ]);
        }
    }
}
