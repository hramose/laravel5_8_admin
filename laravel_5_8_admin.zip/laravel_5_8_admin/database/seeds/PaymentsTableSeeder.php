<?php
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class PaymentsTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        foreach (range(1, 10) as $index) {
            DB::table('payments')->insert([
                'user_id' => 1,
                'subscription_id' => 1,
                'pay_amount' => $faker->randomNumber(2),
                'transaction_id' => $faker->swiftBicNumber,
                'transaction_response' => $faker->text($maxNbChars = 25),
                'status' => 'Complete',
                'transaction_date_time' => $faker->DateTime,
                'created_at' => $faker->DateTime,
                
            ]);
        }
    }
}
