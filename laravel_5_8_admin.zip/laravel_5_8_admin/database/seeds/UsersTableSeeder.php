<?php
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class UsersTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        foreach (range(1, 10) as $index) {
            DB::table('users')->insert([
                'first_name' => $faker->firstName,
                'last_name' => $faker->lastName,
                'username' =>$faker->unique()->userName,
                'password' => bcrypt('123456'),
                'contact_number' => $faker->phoneNumber,
                'email' => preg_replace('/@example\..*/', '@mailinator.com', $faker->unique()->safeEmail),
                'slug' => $faker->slug,
                'remember_token' => str_random(10),
                'role_id' => rand(1, 3),
                'status' => 'Active',
                'verify_status' => 'Pending',
                'role_id' => '3',
                'created_at' => $faker->DateTime
            ]);
        }
    }
}
