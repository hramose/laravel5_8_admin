<?php
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Faker\Factory as Faker;

class RatingReviewsTableSeeder extends Seeder
{

    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create();
        foreach (range(1, 10) as $index) {
            DB::table('rating_reviews')->insert([
                'from_user_id' => 1,
                'to_user_id' => 1,
                'rating' => rand(1,5),
                'review' => $faker->text($maxNbChars = 25),
                'status' => 'Approve',
                'created_at' => $faker->DateTime,
                
            ]);
        }
    }
}
