<?php
namespace App\Helpers;

class CommonHelper 
{   
    public static function fetchActiveCmsPages() 
    {
        return \App\Models\CmsPage::where('status', '=', 'Active')
                                    ->orderBy('title')
                                    ->get();
    }

    public static function fetchGlobalSettingValueByName($name = Null)
    {
        return \App\Models\GlobalSetting::where('name', '=', $name)->select('value')->pluck('value')->first();
    }   
}
