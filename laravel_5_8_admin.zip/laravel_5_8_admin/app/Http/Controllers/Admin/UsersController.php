<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\BaseController;
use Illuminate\Http\Request;
//use Illuminate\Support\Facades\Storage;

class UsersController extends BaseController 
{
    public function __construct() {
        parent::__construct();
    }

    public function index(Request $request) {        
        $userModel = new \App\Models\User();
        
        $data = $this->getViewData();
        
        $data['mainTitle'] = 'Manage Users';
        $data['breadCrumData'][1]['text'] = 'Manage Users'; 
        
        $data['users'] = $userModel->fetchAllUsers($request, 'User');
        
        return \View('admin.users.index')->with($data);
    }    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  $id String:id encrypted
     * @return \Illuminate\Http\Response
     */
    public function edit($id = null) {
        $id = \Crypt::decryptString($id);
        
        $data = $this->getViewData();
        
        $data['mainTitle'] = 'Manage Users';
        $data['subTitle'] = 'Edit User';
        
        $data['breadCrumData'][1]['text'] = 'Manage Users';
        $data['breadCrumData'][1]['url'] = url('/admin/users');
        $data['breadCrumData'][1]['breadFaClass'] = 'fa-th-list';
        $data['breadCrumData'][2]['text'] = 'Edit User';

        $data['countryList'] = \App\Models\Country::pluck('name', 'id');
        $data['stateList'] = \App\Models\State::where('country_id', '=', 1)->pluck('name', 'id'); //US states list
        $data['cityList'] = [];

        $data['user'] = \App\Models\Farmer::FindOrFail($id);
        if (!empty($data['user']->state_id)) {
            $data['cityList'] = \App\Models\City::where('state_id', '=', $data['user']->state_id)->pluck('name', 'id');
        }
        
        $data['status'] = $this->getEnumValues('users', 'status');
        $data['user'] = \App\Models\User::FindOrFail($id);        
        
        return \View::make('admin.users.edit')->with($data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \anatta\Model\User  $farmer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id = null) {
        $id = \Crypt::decryptString($id);
        
        if ($request->isMethod('PUT')) {
            $userModel = new \App\Models\User();
            
            $user = \App\Models\User::FindOrFail($id);
            
            $request->request->add(['slug' => str_slug($request->name, "-")]);
            
            $validation = \Validator::make($request->all(), $userModel->rules($user), $userModel->messages());
            
            if ($validation->fails()) {
                return \Redirect::back()->withInput()->withErrors($validation->messages());
            }
            
            $input = $request->except(['_token', 'delete_image']);
            $deleteImageFlag = false;
            
            if (!empty($input['image'])) {
                $params['thumbSavePath'] = 'users';
                    
                $params['file'] = $input['image'];
                $params['savePath'] = 'users';
                
                $returnData = $this->imageUpload($params);
                
                if ($returnData['status']) {
                    $input['image'] = $returnData['fileName'];
                }
                
                if (!empty($user->image)) {
                    $deleteImageFlag = true;
                }
            }
            
            // delete image
            if (!empty($request->delete_image) || $deleteImageFlag) {
                $this->deleteImage('users', $user->image);
            }
            
            $user->fill($input)->save();
            
            \Session::flash('success', __('messages.User.Updated'));
            
            //return \Redirect::to('admin/users');
            return \Redirect::back();
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \anatta\Model\User  $farmer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request, $id = null) {
        $id = \Crypt::decryptString($id);
        
        try {
            \DB::beginTransaction();
            
            $user = \App\Models\User::find($id);

            //images delete code
            if (!empty($user->image)) {
                $this->deleteImage('users', $user->image);
            }
            
            $user->delete();
            \DB::commit();

            \Session::flash('success', __('messages.User.Deleted'));
        } catch (\Exception $e) {
            \DB::rollBack();
            \Session::flash('error', __('messages.User.AssignedNotDeleted'));
        }
        
        return \Redirect::to('admin/users');
    }

    public function show($id = null) {     
        $id = \Crypt::decryptString($id);
        
        $data = $this->getViewData();
        
        $data['subTitle'] = 'View User';        
        $data['mainTitle'] = 'Manage Users';
        $data['breadCrumData'][1]['text'] = 'Manage Users';
        $data['breadCrumData'][1]['url'] = url('/admin/users');
        $data['breadCrumData'][1]['breadFaClass'] = 'fa-th-list';
        $data['breadCrumData'][2]['text'] = 'View User';
        
        $data['user'] = \App\Models\User::FindOrFail($id);
        
        return \View('admin.users.view')->with($data);
    }    
}
