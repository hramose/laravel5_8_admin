<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;

class PaymentsController extends BaseController
{
    public function __construct() {
        parent::__construct();
    }

    public function index(Request $request)
    {
        try{
            $paymentModel = new \App\Models\Payment();     

            $data = $this->getViewData();

            $data['mainTitle'] = 'Manage Payments';
            $data['breadCrumData'][1]['text'] = 'Manage Payments';
            
            $data['payments'] = $paymentModel->getAllPayments($request);

            return \View('admin.payments.index')->with($data);

        }catch (Exception $ex) {
            return redirect()->back()->withErrors($ex->getMessage() . " In " . $ex->getFile() . " At Line " . $ex->getLine())->withInput();
        }        
    }
    
    public function downloadTransactionCsv($id = null)
    {
        try {
            $id = \Crypt::decryptString($id);
            
            $transaction = \App\Models\Payment::FindOrFail($id);
            
            $filename = "transaction.csv";
            $handle = fopen('php://output', 'w');

            fputcsv($handle, array('Transaction Id', 'Transaction Date Time', 'Post Name & ID', 'User Name', 'Transaction Amount'));

            if (!empty($transaction) && is_object($transaction)) {                
                fputcsv($handle, array(
                                    $transaction->transaction_id, 
                                    $transaction->transaction_date_time, \
                                    ucfirst($transaction->Post->title) . '(' . $transaction->Post->id . ')',
                                    $transaction->User->name, 
                                    \Config::get('constants.CurrencySign') . $transaction->pay_amount
                                ));
            }

            fclose($handle);

            header('Content-type: text/csv');
            header('Content-Disposition: attachment; filename="' . $filename . '"');
            header('Pragma: no-cache');
            header('Expires: 0');

            exit();
        } catch (Exception $ex) {
            return redirect()->back()->withErrors($ex->getMessage() . " In " . $ex->getFile() . " At Line " . $ex->getLine())->withInput();
        }
    }


    public function show($id = null)
    {
        $id = \Crypt::decryptString($id);
            
        $data = $this->getViewData();

        $data['mainTitle'] = 'Manage Payments';
        $data['subTitle'] = 'Payment Detail';
        $data['breadCrumData'][1]['text'] = 'Manage Payments';
        $data['breadCrumData'][1]['url'] = url('/admin/payments');
        $data['breadCrumData'][1]['breadFaClass'] = 'fa-th-list';
        $data['breadCrumData'][2]['text'] = 'Payment Details';

        $data['transaction'] = \App\Models\Payment::FindOrFail($id);

        return \View('admin.payments.view')->with($data);
    }    
}
