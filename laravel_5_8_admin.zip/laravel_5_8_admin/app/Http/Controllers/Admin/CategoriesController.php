<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\BaseController;
use Illuminate\Http\Request;

class CategoriesController extends BaseController 
{
    public function __construct() {
        parent::__construct();
    }

    public function index(Request $request) {
        $categoryModel = new \App\Models\Category();
        
        $data = $this->getViewData(); 
        
        $data['categoryList'] = $categoryModel->fetchAllCategories($request);
        
        $data['mainTitle'] = 'Manage Categories';
        $data['breadCrumData'][1]['text'] = 'Manage Categories';  
        
        return \View('admin.categories.index')->with($data);
    }

    public function create() {
        $data = $this->getViewData();
        
        $data['mainTitle'] = 'Manage Categories';
        $data['subTitle'] = 'Create Category';
        $data['breadCrumData'][1]['text'] = 'Manage Categories';
        $data['breadCrumData'][1]['url'] = url('/admin/categories');
        $data['breadCrumData'][1]['breadFaClass'] = 'fa-th-list';
        $data['breadCrumData'][2]['text'] = 'Create Category';
        
        $data['status'] = $this->getEnumValues('categories', 'status');
        $data['category'] = [];
        
        return \View('admin.categories.edit')->with($data);
    }

    public function store(Request $request) {
        if ($request->isMethod('POST')) {
            $categoryModel = new \App\Models\Category();
            
            $validation = \Validator::make($request->all(), $categoryModel->rules());
            
            if ($validation->fails()) {
                return \Redirect::back()->withInput()->withErrors($validation->messages());
            }
           
            $request->request->add(['slug' => str_slug($request->name, "-")]);
            
            $input = $request->except(['_token']);
            
            $category = \App\Models\Category::create($input);
            
            if (!empty($category->id)) {
                \Session::flash('success', __('messages.Category.Added'));
                
                return \Redirect::to('admin/categories');
            } else {
                return back()->with('error', __('messages.Category.NotSaved'));
            }
        }
    }

    public function edit($id = null) {
        $id = \Crypt::decryptString($id);
        
        $data = $this->getViewData();
        
        $data['mainTitle'] = 'Manage Categories';
        $data['subTitle'] = 'Edit Category';
        $data['breadCrumData'][1]['text'] = 'Manage Categories';
        $data['breadCrumData'][1]['url'] = url('/admin/categories');
        $data['breadCrumData'][1]['breadFaClass'] = 'fa-th-list';
        $data['breadCrumData'][2]['text'] = 'Edit Category';
        
        $category = \App\Models\Category::FindOrFail($id);
        $data['category'] = $category;
        
        $data['status'] = $this->getEnumValues('categories', 'status');
        
        return \View::make('admin.categories.edit')->with($data);
    }

    public function update(Request $request, $id) {
        $id = \Crypt::decryptString($id);
        
        $categoryModel = new \App\Models\Category();
        
        $category = \App\Models\Category::FindOrFail($id);
        
        if ($request->isMethod('PUT')) {
            $validation = \Validator::make($request->all(), $categoryModel->rules($category->id));
            
            if ($validation->fails()) {
                return \Redirect::back()->withInput()->withErrors($validation->messages());
            }
            
            $request->request->add(['slug' => str_slug($request->name, "-")]);
            
            $input = $request->except(['_token']);
            
            $updateStatus = $category->update($request->all());

            if($updateStatus)
            {
                \Session::flash('success', __('messages.Category.Updated'));

                //return \Redirect::to('/admin/categories');
                return \Redirect::back()->withInput();
            }
            else
            {
                \Session::flash('error', __('messages.Category.NotUpdated'));

                return \Redirect::back()->withInput();
            }
        }
    }

    public function destroy($id = null) {
        $id = \Crypt::decryptString($id);
        
        try {
            \DB::beginTransaction();
            
            $category = \App\Models\Category::find($id);
            $category->delete();
                
                \DB::commit();
                
                \Session::flash('success', __('messages.Category.Deleted'));
            
        } catch (\Exception $e) {
            \DB::rollBack();

            \Session::flash('error', __('messages.Category.AssignedNotDeleted'));
        }
        
        return \Redirect::to('admin/categories');
    }
}