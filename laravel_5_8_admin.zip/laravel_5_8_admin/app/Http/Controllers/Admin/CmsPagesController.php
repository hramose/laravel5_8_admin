<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\BaseController;
use Illuminate\Http\Request;

class CmsPagesController extends BaseController
{     
    public function __construct() {
        parent::__construct();
    }
    
    public function index(Request $request)
    {
        $cmsPageModel = new \App\Models\CmsPage();
        
        $data = $this->getViewData();
        
        $data['mainTitle'] = 'Manage CMS';
        $data['subTitle'] = 'Manage CMS';
        $data['breadCrumData'][1]['text'] = 'Manage CMS';
        
        $data['cmsPages'] = $cmsPageModel->fetchAllCmsPages($request);

        return \View::make('admin.cms_pages.index')->with($data);
    }
    
    public function create()
    {
	    $data = $this->getViewData();
        
        $data['mainTitle'] = 'Manage CMS';
        $data['subTitle'] = 'Create CMS';
        $data['breadCrumData'][1]['text'] = 'Manage CMS';
        $data['breadCrumData'][1]['url'] = url('/admin/cms-pages');
        $data['breadCrumData'][1]['breadFaClass'] = 'fa-th-list';
        $data['breadCrumData'][2]['text'] = 'Create CMS';
        
        $data['cmsPage'] = [];
        
        return \View::make('admin.cms_pages.edit')->with($data);		
    }

    public function store(Request $request)
    {
        $cmsPageModel = new \App\Models\CmsPage();
        
        $request->request->add(['slug' => str_slug($request->title, "-")]);

        $validation = \Validator::make($request->all(), $cmsPageModel->rules());

        if($validation->fails())
        {
            return \Redirect::back()->withInput()->withErrors($validation->messages());
        }

        $input = $request->except(['_token']);

        $cmsPage = \App\Models\CmsPage::create($input);

        if(!empty($cmsPage->id))
        {
            \Session::flash('success', __('messages.Cms.Added'));	

            return \Redirect::to('/admin/cms-pages');
        }
        else
        {
            return back()->with('error', __('messages.Cms.NotSaved'));
        }	
    }
    
    public function edit($id)
    {
        $id = \Crypt::decryptString($id);
		
        $data = $this->getViewData();
        
        $data['mainTitle'] = 'Manage CMS';
        $data['subTitle'] = 'Edit CMS';
        $data['breadCrumData'][1]['text'] = 'Manage CMS';
        $data['breadCrumData'][1]['url'] = url('/admin/cms-pages');
        $data['breadCrumData'][1]['breadFaClass'] = 'fa-th-list';
        $data['breadCrumData'][2]['text'] = 'Edit CMS';
	
        $data['cmsPage'] = \App\Models\CmsPage::find($id);
        
        return \View::make('admin.cms_pages.edit')->with($data);
    }

    public function update(Request $request, $id)
    {
        $id = \Crypt::decryptString($id);
		
        $cmsPageModel = new \App\Models\CmsPage();

        $cmsPage = \App\Models\CmsPage::FindOrFail($id);

        $request->request->add(['slug' => $cmsPage->slug]);

        $validation = \Validator::make($request->all(), $cmsPageModel->rules());

        if($validation->fails())
        {
            return \Redirect::back()->withInput()->withErrors($validation->messages());
        }
        else
        {            
            $updateStatus = $cmsPage->update($request->all());

            if($updateStatus)
            {
                \Session::flash('success', __('messages.Cms.Updated'));

                //return \Redirect::to('/admin/cms-pages');
                return \Redirect::back()->withInput();
            }
            else
            {
                \Session::flash('error', __('messages.Cms.NotUpdated'));

                return \Redirect::back()->withInput();
            }
        }
    }
    
    public function destroy($id)
    {
        $id = \Crypt::decryptString($id);
		
	\App\Models\CmsPage::destroy($id);

        \Session::flash('success', __('messages.Cms.Deleted'));
		
        return \Redirect::to('/admin/cms-pages');
    }
}
