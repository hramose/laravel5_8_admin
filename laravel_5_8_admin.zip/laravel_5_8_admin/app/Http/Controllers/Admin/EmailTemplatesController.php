<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;

class EmailTemplatesController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
    }
	
    /**
    * Display a listing of the resource.
    *
    * @return \Illuminate\Http\Response
    */
    public function index(Request $request)
    {           
        $emailTemplateModel = new \App\Models\EmailTemplate();

        $data = $this->getViewData();

        $data['mainTitle'] = 'Manage Email Templates';
        $data['breadCrumData'][1]['text'] = 'Manage Email Templates';

        $data['emailTemplateList'] = $emailTemplateModel->fetchAllEmailTemplates($request);

        return \View::make('admin.email_templates.index')->with($data);
    }    

    /**
    * Show the form for editing the specified resource.
    *
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
    public function edit($id)
    {
        $id = \Crypt::decryptString($id);
		
        $data = $this->getViewData();

        $data['mainTitle'] = 'Manage Email Templates';
        $data['subTitle'] = 'Edit Email Template';
        
        $data['breadCrumData'][1]['text'] = 'Manage Email Templates';
        $data['breadCrumData'][1]['url'] = url('/admin/email-templates');
        $data['breadCrumData'][1]['breadFaClass'] = 'fa-th-list';
        $data['breadCrumData'][2]['text'] = 'Edit Email Template';
        
        $data['emailTemplate'] = \App\Models\EmailTemplate::find($id);

        return \View::make('admin.email_templates.edit')->with($data);
    }

    /**
    * Update the specified resource in storage.
    *
    * @param  \Illuminate\Http\Request  $request
    * @param  int  $id
    * @return \Illuminate\Http\Response
    */
    public function update(Request $request, $id)
    {
        $id = \Crypt::decryptString($id);
		
        $emailTemplateModel = new \App\Models\EmailTemplate();
		
        $emailTemplate = \App\Models\EmailTemplate::FindOrFail($id);

        $request->request->add(['type' => $emailTemplate->type]);

        $validation = \Validator::make($request->all(), $emailTemplateModel->rules());

        if($validation->fails())
        {
            return \Redirect::back()->withInput()->withErrors($validation->messages());
        }
        else
        {            
            $emailTemplate->subject = $request->subject;
            $emailTemplate->body = $request->body;

            if($emailTemplate->save())
            {
                \Session::flash('success', __('messages.EmailTemplate.Updated'));

                //return \Redirect::to('admin/email-templates');
                return \Redirect::back()->withInput();
            }
            else
            {
                \Session::flash('error', __('messages.EmailTemplate.NotUpdated'));

                return \Redirect::back()->withInput();
            }
        }
    }
}