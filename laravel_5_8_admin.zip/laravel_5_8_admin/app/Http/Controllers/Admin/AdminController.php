<?php
namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Admin\BaseController;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Support\Facades\Cache;

class AdminController extends BaseController {
    /*too many login attempts*/
    use AuthenticatesUsers;    
    protected $decayMinutes  = 10; //value is in minutes
    protected $maxAttempts = 5; //lockout after attempts
    
    protected $adminRoleId = 1;

    public function __construct() {
        parent::__construct();
    }
    
    /**
    * Determine if the user has too many failed login attempts.
    *
    * @param  \Illuminate\Http\Request  $request
    * @return bool
    */
    protected function hasTooManyLoginAttempts(Request $request)
    {
        return $this->limiter()->tooManyAttempts(
            $this->throttleKey($request), $this->maxAttempts, $this->decayMinutes
        );
    }

    public function login(Request $request) {
        if (\Auth::check()) {
            return \Redirect::to('/admin/dashboard');
        }

        $data['displayRecaptcha'] = false;
        $invalidAttemptsCount = 0; //$this->limiter()->attempts($this->throttleKey($request));
        $cacheFileName = 'invalid_count_' . $request->ip();
        
        if (Cache::has($cacheFileName)) {
            $invalidAttemptsCount = Cache::get($cacheFileName);
        }
        
        if($invalidAttemptsCount > 2){ 
            $data['displayRecaptcha'] = true;
        }

        if ($request->isMethod('POST')) {
            $validator = \Validator::make($request->all(), ['username' => 'required', 'password' => 'required']);

            $remember = ($request->has('remember')) ? true : false;

            if ($validator->fails()) {
                return \Redirect::back()->withErrors($validator);
            } else {                
                /*too many login attempts*/
                if ($this->hasTooManyLoginAttempts($request)) {
                    $this->fireLockoutEvent($request);
                    
                    \Session::flash('error', $this->sendLockoutResponse($request));

                    return \Redirect::back();
                }
                
                $isValidCaptcha = true;               
                                
                if($invalidAttemptsCount > 3){
                    $input = $request->except(['_token']);
                    $captchaResponse = $input['g-recaptcha-response'];

                    $isValidCaptcha = $this->verifyCaptcha($captchaResponse);
                }                   

                if(!$isValidCaptcha)
                {
                    return \Redirect::back()->withErrors(__('messages.VerifyCaptcha')); //->withInput($input);
                }
                else
                {
                    
                    if (\Auth::attempt(['username' => $request->username, 'password' => $request->password, 'status' => 'Active', 'role_id' => $this->adminRoleId], $remember)) {
                        /*too many login attempts*/
                        $this->clearLoginAttempts($request);
                        
                        Cache::forget($cacheFileName);

                        return \Redirect::to('admin/dashboard');
                    }else {
                        /*too many login attempts*/
                        $this->incrementLoginAttempts($request);
                                                
                        Cache::put($cacheFileName, $invalidAttemptsCount+1, $this->decayMinutes);
                        
                        \Session::flash('error', __('messages.LoginInvalid'));

                        return \Redirect::back();
                    }
                }                
            }
        }

        return view('admin/admin/login')->with($data);
    }

    public function logout() {
        try {
            \Auth::logout();

            \Session::flash('success', __('messages.LogoutSuccess'));

            return \Redirect::to('admin');
        } catch (\Illuminate\Database\QueryException $e) {
            return \Redirect::to('admin');
        }
    }

    public function dashboard(Request $request) {
        $data['userCount'] = \App\Models\User::whereHas('Role', function ($q){
                                                $q->where('name', '=', 'user');
                                            })
                                            ->count();
        
        $data['latestUsers'] = \App\Models\User::whereHas('Role', function ($q){
                                                        $q->where('name', '=', 'user');
                                                    })
                                                    ->limit(5)
                                                    ->orderBy('id', 'desc')
                                                    ->get();
                                                    
        $data['farmerCount'] = \App\Models\User::whereHas('Role', function ($q){
                                                $q->where('name', '=', 'farmer');
                                            })
                                            ->count();
                                                    
        $data['latestFarmers'] = \App\Models\User::whereHas('Role', function ($q){
                                                        $q->where('name', '=', 'farmer');
                                                    })
                                                    ->limit(5)
                                                    ->orderBy('id', 'desc')
                                                    ->get();

        $data['latestPayments'] = \App\Models\Payment::with('user')
                                                    ->limit(5)
                                                    ->orderBy('id', 'desc')
                                                    ->get();
                                                    
        $data['latestReviews'] = \App\Models\RatingReview::with('user', 'farmer')
                                                    ->limit(5)
                                                    ->orderBy('id', 'desc')
                                                    ->get();    
                                                    
        $data['mainTitle'] = 'Dashboard';

        return view('admin/admin/dashboard')->with($data);
    }

    public function notificationSettings(Request $request) {
        $user = \Auth::user();

        if ($request->isMethod('POST')) {                         
            if ($request->has('want_email_notification')){
                $user->want_email_notification = $request->want_email_notification;
            }else{                    
                $user->want_email_notification = 'No';
            }

            \Auth::user()->setAttribute('want_email_notification', $user->want_email_notification);

            $user->save();
                
            $notificationSettingData = [
                                            'user_id' => \Auth::user()->id,
                                            'want_rating_review_email' => $request->has('want_rating_review_email') ? $request->want_rating_review_email : 'No',
                                            'want_profile_review_email' => $request->has('want_profile_review_email') ? $request->want_profile_review_email : 'No',
                                            'want_payment_email' => $request->has('want_payment_email') ? $request->want_payment_email : 'No'
                                        ];                    

            $notificationSetting = \App\Models\NotificationSetting::updateOrCreate(['user_id' => \Auth::user()->id], $notificationSettingData);
            
            \Session::flash('success', __('messages.NotificationSettingsUpdated'));
        }
        
        $data = $this->getViewData();
        $data['notificationSetting'] = \App\Models\NotificationSetting::where('user_id', '=', \Auth::user()->id)->first();
        
        $data['mainTitle'] = 'Manage Account Settings';
        $data['subTitle'] = 'Notification Settings';
        $data['breadCrumData'][1]['text'] = 'Manage Account Settings';
        $data['breadCrumData'][1]['breadFaClass'] = '';
        $data['breadCrumData'][2]['text'] = 'Notification Settings';

        return view('admin/admin/notification_settings', $data);
    }

    public function changePassword(Request $request) {
        if ($request->isMethod('POST')) {
            $user = \Auth::user();
            
            $rules = array(
                'current_password' => 'required',
                'password' => 'required|between:8,15|confirmed'
            );
            
            $message = array('confirmed' => "Password entered doesn't match.");

            $validator = \Validator::make($request->all(), $rules, $message);

            if ($validator->fails()) {
                return \Redirect::route('changePassword')->withErrors($validator);
            } else {
                if (!\Hash::check($request->get('current_password'), $user->password)) {
                    return \Redirect::route('changePassword')->withErrors(__('messages.PasswordNotMatch'));
                }else if (\Hash::check($request->get('password'), $user->password)) {
                    return \Redirect::route('changePassword')->withErrors(__('messages.PasswordMustBeDifferent'));
                }else {
                    $user->password = bcrypt($request->get('password'));
                    $user->save();

                    \Session::flash('success', __('messages.PasswordChanged'));

                    return \Redirect::route('changePassword');
                }
            }
        }

        $data = $this->getViewData();

        $data['mainTitle'] = 'Manage Account Settings';
        $data['subTitle'] = 'Change Password';
        
        $data['breadCrumData'][1]['text'] = 'Manage Account Settings';
        $data['breadCrumData'][1]['breadFaClass'] = '';
        $data['breadCrumData'][2]['text'] = 'Change Password';

        return view('admin/admin/change_password', $data);
    }
    
    public function forgotPassword(Request $request) {
        if (\Auth::check()) {
            return \Redirect::to('dashboard');
        }

        if ($request->isMethod('POST')) {
            $validator = \Validator::make($request->all(), ['username' => 'required']);

            if ($validator->fails()) {
                return \Redirect::back()->withErrors($validator);
            } else {
                $input = $request->all();

                $user = \App\Models\User::where([['role_id', '=', $this->adminRoleId], ['username', '=', $request->username]])->first();

                if ($user) {
                    
                    //send reset link in mail and make entry in db of reset pwd token
                    $resetPasswordToken = urlencode(strtolower(\Hash::make($user->id . rand())));

                    $result = \DB::table('users')->where('id', $user->id)->update(['reset_password_token' => $resetPasswordToken]);

                    if ($result) {
                        $params['toName'] = $user->fullname;
                        $params['toEmail'] = $user->email;
                        $params['emailSlug'] = 'forgot_password';
                        $params['replaceKeywords']['##USER_NAME##'] = $user->fullname;
                        $params['replaceKeywords']['##RESET_PASSWORD_LINK##'] = url('/') . '/admin/reset-password?rpt=' . $resetPasswordToken;
                        $this->sendMail($params);

                        \Session::flash('success', __('messages.PasswordResetLinkSent'));
                    } else {
                        return \Redirect::back()->withErrors(__('messages.TryAgain'))->withInput($input);
                    }
                } else {
                    return \Redirect::back()->withErrors(__('messages.WrongEmailId'))->withInput($input);
                }
            }
        }

        $data['htmlTitle'] = "Forgot Password";

        return view('admin/admin/forgot_password', $data);
    }

    public function resetPassword(Request $request) {
        if (\Auth::check()) {
            return \Redirect::to('dashboard');
        }

        if (!empty($request->query('rpt'))) {
            $resetPasswordToken = urlencode($request->query('rpt'));

            if ($request->isMethod('POST')) {
                $validator = \Validator::make($request->all(), ['password' => 'required|confirmed']);

                if ($validator->fails()) {
                    return \Redirect::back()->withErrors($validator);
                } else {
                    $input = $request->all();

                    $user = \App\Models\User::where([['reset_password_token', '=', $resetPasswordToken], ['role_id', '=', $this->adminRoleId]])->first();

                    if ($user) {
                        $newPassword = bcrypt($request['password']);

                        $result = \App\Models\User::where('id', $user->id)->update(['password' => $newPassword, 'reset_password_token' => '']);

                        if ($result) {
                            \Session::flash('success', __('messages.PasswordResetSuccess'));

                            return \Redirect::to('admin');
                        } else {
                            return \Redirect::back()->withErrors(__('messages.PasswordResetFail'))->withInput($input);
                        }
                    } else {
                        return \Redirect::back()->withErrors(__('messages.PasswordResetInvalidLink'));
                    }
                }
            }
        } else {
            return \Redirect::back()->withErrors(__('messages.PasswordResetInvalidLink'));
        }

        $data['htmlTitle'] = "Reset Password";

        $data['resetPasswordToken'] = $resetPasswordToken;

        return view('admin/admin/reset_password', $data);
    }
}
