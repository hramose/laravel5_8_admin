<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\BaseController;
use Illuminate\Http\Request;

class SiteSettingsController extends BaseController
{     
    public function __construct() {
        parent::__construct();
    }
    
    public function globalSettings(Request $request)
    {
        $globalSettingModel = new \App\Models\GlobalSetting();
        
        $data = $this->getViewData();
        
        $data['globalSettings'] = $globalSettingModel->fetchAllGlobalSettings($request);
        
        $data['mainTitle'] = 'Global Settings';
        $data['breadCrumData'][1]['text'] = 'Manage Site Settings';
        $data['breadCrumData'][1]['breadFaClass'] = '';
        $data['breadCrumData'][2]['text'] = 'Global Settings';
        
        return view('admin/site_settings/global_settings', $data);
    }

    public function updateGlobalSetting(Request $request, $id = null)
    {
        $id = \Crypt::decryptString($id);
        
        if ($request->isMethod('POST'))
        {
            $globalSetting = \App\Models\GlobalSetting::findOrFail($id);
            
            $input = $request->only('value');
            
            if($globalSetting->fill($input)->save())
            {
                return $this->sendResponse($globalSetting, __('messages.GlobalSetting.Updated'));
            }
            
            return $this->sendError(__('messages.GlobalSetting.NotUpdated'));
        }
    }
    
    public function smtpSettings(Request $request)
    {
        $data = $this->getViewData();
        
        $data['smtpSettings'] = \App\Models\SmtpSetting::first();
        
        $data['mainTitle'] = 'SMTP Settings';
        $data['breadCrumData'][1]['text'] = 'Manage Site Settings';
        $data['breadCrumData'][1]['breadFaClass'] = '';
        $data['breadCrumData'][2]['text'] = 'SMTP Settings';
        
        return view('admin/site_settings/smtp_settings', $data);
    }

    public function updateSmtpSetting(Request $request, $id = null)
    {
        if($request->isMethod('POST')) 
        {
            $id = !empty($id) && isset($id) ? \Crypt::decryptString($id) : '';

            $smtpSettingModel = new \App\Models\SmtpSetting();
            
            $validation = \Validator::make($request->all(), $smtpSettingModel->rules());

            if ($validation->fails()) 
            {
                return \Redirect::back()->withInput()->withErrors($validation->messages());
            }
            
            $input = $request->except(['_token']);

            if(!empty($id))
            {
                $smtpSetting = \App\Models\SmtpSetting::FindOrFail($id);

                $input['id'] = $smtpSetting->id;

                $smtpSetting->fill($input)->save();

                \Session::flash('success', __('messages.SmtpSetting.Updated'));

                return \Redirect::to('admin/smtp-settings');
            } 
            else 
            {
                $smtpSetting = \App\Models\SmtpSetting::create($input);            

                if (!empty($smtpSetting->id)) 
                {
                    \Session::flash('success', __('messages.SmtpSetting.Added'));
                    
                    return \Redirect::to('admin/smtp-settings');
                } 
                else 
                {
                    return \Redirect::back()->withInput()->with('error', __('messages.SmtpSetting.NotSaved'));
                }
            }
        }
    }
    
    public function mailingAddressesSettings(Request $request)
    {
        $data = $this->getViewData();
        
        $data['mailingAddressesSettings'] = \App\Models\MailingAddressesSetting::first();
        
        $data['mainTitle'] = 'Mailing Addresses Settings';
        $data['breadCrumData'][1]['text'] = 'Manage Site Settings';
        $data['breadCrumData'][1]['breadFaClass'] = '';
        $data['breadCrumData'][2]['text'] = 'Mailing Addresses Settings';
        
        return view('admin/site_settings/mailing_addresses_settings', $data);
    }
    
    public function updateMailingAddressesSettings(Request $request, $id = null)
    {
        if($request->isMethod('POST')) 
        {
            $id = !empty($id) && isset($id) ? \Crypt::decryptString($id) : '';

            $mailingAddressesSettingModel = new \App\Models\MailingAddressesSetting();
            
            $validation = \Validator::make($request->all(), $mailingAddressesSettingModel->rules());

            if ($validation->fails()) 
            {
                return \Redirect::back()->withInput()->withErrors($validation->messages());
            }
            
            $input = $request->except(['_token']);

            if(!empty($id))
            {
                $mailingAddressesSetting = \App\Models\MailingAddressesSetting::FindOrFail($id);

                $input['id'] = $mailingAddressesSetting->id;

                $mailingAddressesSetting->fill($input)->save();

                \Session::flash('success', __('messages.MailingAddressesSetting.Updated'));

                return \Redirect::to('admin/mailing-addresses-settings');
            } 
            else 
            {
                $mailingAddressesSetting = \App\Models\MailingAddressesSetting::create($input);            

                if (!empty($mailingAddressesSetting->id)) 
                {
                    \Session::flash('success', __('messages.MailingAddressesSetting.Added'));
                    
                    return \Redirect::to('admin/mailing-addresses-settings');
                } 
                else 
                {
                    return \Redirect::back()->withInput()->with('error', __('messages.MailingAddressesSetting.NotSaved'));
                }
            }
        }
    }
}

