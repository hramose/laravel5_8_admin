<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class BaseController extends Controller
{
    public function __construct() {
        $this->middleware('admin.auth', ['except' => ['login', 'logout', 'forgotPassword', 'resetPassword']]);
    }
    
    public function getViewData() {
        $data['faClass'] = 'fa-table';
        $data['breadCrumData'][0]['text'] = 'Dashboard';
        $data['breadCrumData'][0]['url'] = url('/admin/dashboard');
        $data['breadCrumData'][0]['breadFaClass'] = 'fa fa-television';
        
        return $data;
    }

    public function updateStatus(Request $request)
    {
        if ($request->id != null) {
            try {
                $id = \Crypt::decryptString($request->id);
                $tableName = \Crypt::decryptString($request->model);
                
                $tableData = \DB::table($tableName)->select('status')->find($id);

                $updateStatusTo = '';

                if ($tableData->status == 'Active') {
                    $updateStatusTo = 'Inactive';
                }elseif ($tableData->status == 'Inactive') {
                    $updateStatusTo = 'Active';
                }else if($tableData->status == 'Pending'){
                    $updateStatusTo = 'Approve';
                }else if($tableData->status == 'Approve'){
                    $updateStatusTo = 'Reject';
                }else if($tableData->status == 'Reject'){
                    $updateStatusTo = 'Approve';
                } 

                $result = \DB::table($tableName)->where('id', $id)->update(['status' => $updateStatusTo]);
                
                if ($result) {
                    return $this->sendResponse(['status' => $updateStatusTo, 'div_id' => $id], __('messages.StatusUpdated'));
                }
            } catch (\Exception $e) {
                //$msg = 'Error: ' . $e->getMessage();
            }
        }

        return $this->sendError(__('messages.StatusNotUpdated'));
    }
    
    public function checkUsernameAvailability(Request $request){        
        $id = !empty($request->userId) ? \Crypt::decryptString($request->userId) : '';
        
        $rules = ['username' => 'unique:users,username,' . ($id ? $id : '')];

        $validator = \Validator::make($request->all(), $rules);

        if($validator->fails()){
            return response()->json(false);
        }else{
            return response()->json(true);
        }
    }
    
    public function checkEmailAvailability(Request $request){        
        $id = !empty($request->userId) ? \Crypt::decryptString($request->userId) : '';
        $roleId = !empty($request->roleId) ? \Crypt::decryptString($request->roleId) : '';
        
        $validator = \Validator::make($request->all(), [
                            'email' => [
                                'required',
                                \Illuminate\Validation\Rule::unique('users')->where(function ($query) use($id, $roleId){
                                    $query->where('role_id', '=', $roleId);
                                    
                                    if(!empty($id)){
                                        $query->where('id', '!=', $id);
                                    }
                                })
                            ],
                        ]);

        if($validator->fails()){
            return response()->json(false);
        }else{
            return response()->json(true);
        }
    }
}
