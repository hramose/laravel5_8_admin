<?php
namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Admin\BaseController;
use Illuminate\Http\Request;

class ReportsController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(Request $request)
    {
        $data = $this->getViewData();

        $data['mainTitle'] = 'Reports';
        $data['breadCrumData'][1]['text'] = 'Reports';

        switch($request->report_type){
            case 'farmer':
                $farmerModel = new \App\Models\Farmer();
                $data['dataList'] = $farmerModel->fetchAllFarmers($request, 'farmer');
                $data['label'] = "Total Farmer";
                break;

            case 'user':
                $userModel = new \App\Models\User();
                $data['dataList'] = $userModel->fetchAllUsers($request, 'user');
                $data['label'] = "Total User";
                break;

            case 'payment':
                $paymentModel = new \App\Models\Payment();
                $data['paymentList'] = $paymentModel->getAllPayments($request);
                break;        
        }
        
        return \View('admin.reports.index')->with($data);
    }
}