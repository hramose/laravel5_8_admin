<?php
namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Image;
use Illuminate\Support\Facades\Storage;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;
    
    //@Author: 
    //@Description: for verify Captcha
    //@Params: $captchaResponse
    //@Return: success response
    protected function verifyCaptcha($captchaResponse = null)
    {
        $params['secret'] = \App\Helpers\CommonHelper::fetchGlobalSettingValueByName('GoogleRecaptchaApiSecret');
        $params['response'] = $captchaResponse;
        $params['remoteip'] = $_SERVER['REMOTE_ADDR'];

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'https://www.google.com/recaptcha/api/siteverify');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $params);

        /*curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query(array('postvar1' => 'value1')));*/

        $serverOutput = json_decode(curl_exec($ch));
        curl_close($ch);

        if (empty($serverOutput->success)) {
            $serverOutput->success = false;
        }

        return $serverOutput->success;
    }  
    
    /*success response method.
    @return \Illuminate\Http\Response*/
    public function sendResponse($data = [], $message = '')
    {
    	$response = [
            'success' => true,
            'data'    => $data,
            'message' => $message,
        ];

        return response()->json($response, 200);
    }

    /*return error response.
    @return \Illuminate\Http\Response*/
    public function sendError($message, $code = 404)
    {
    	$response = [
            'success' => false,
            'message' => $message,
        ];

        return response()->json($response, $code);
    }
    
    //$params['toName'] = $receiverUserName
    //$params['toEmail'] = $receiverEmailId;
    //$params['emailSlug'] = user_register;
    //$params['replaceKeywords']['##PROFILE_NAME##'] = '';
    //$params['replaceKeywords']['##CLAIM_STATUS##'] = '';
    protected function sendMail($params = [])
    {
        if (empty($params['emailSlug'])) {
            return false;
        }

        $emailTemplateModel = new \App\Models\EmailTemplate();

        $params['emailTemplate'] = $emailTemplateModel->fetchEmailTemplateBySlug($params['emailSlug']);
        
        $mailingAddressesSetting = \App\Models\MailingAddressesSetting::first();

        $params['toName'] = !empty($params['toName']) ? $params['toName'] : 'Admin';
        $params['fromName'] = !empty($params['fromName']) ? $params['fromName'] : config('SiteName');
        $params['toEmail'] = !empty($params['toEmail']) ? $params['toEmail'] : $mailingAddressesSetting->admin_email_id;
        $params['fromEmail'] = !empty($params['fromEmail']) ? $params['fromEmail'] : $mailingAddressesSetting->admin_email_id;
        $params['emailSlug'] = $params['emailSlug'];
        $params['attachment'] = !empty($params['attachment']) ? $params['attachment'] : '';
        $params['originalFileName'] = !empty($params['originalFilename']) ? $params['originalFilename'] : '';

        if (!empty($params['noReply'])) {
            $params['fromEmail'] = $mailingAddressesSetting->no_reply_email_id;
        }

        $body = str_replace('##SITE_NAME##', config('SiteName'), $params['emailTemplate']['body']);
        
        if (!empty($params['replaceKeywords'])) {
            foreach ($params['replaceKeywords'] as $keyword => $replaceValue) {
                $body = str_replace($keyword, $replaceValue, $body);
            }
        }

        $params['emailTemplate']['body'] = $body;

        try {
            $commonEmailTemplate = new \App\Mail\CommonEmailTemplate($params);
            
            Mail::to($params['toEmail'])->send($commonEmailTemplate);

            return true;
        } catch (\Exception $e) {
            //echo '<br>error:<pre>';print_r($e->getMessage());die;
            
            return false;
        }
    }
    
    // @Author: .
    // get listing of the EnumValues.
    // @return listing of the EnumValues
    public function getEnumValues($table, $column)
    {
        $type = \DB::select(\DB::raw("SHOW COLUMNS FROM $table WHERE Field = '{$column}'"))[0]->Type ;

        preg_match('/^enum\((.*)\)$/', $type, $matches);

        $enum = array();

        foreach (explode(',', $matches[1]) as $value) {
            $v = trim($value, "'");
            $enum = array_add($enum, $v, $v);
        }

        return $enum;
    }
    
    /* $params['fileCrop'] = false;
    * $params['xCord'] = 253;
    * $params['yCord'] = 153;
    * refrence url : http://image.intervention.io  */
    public function imageUpload($params)
    {
        $returnData['status'] = false;
        $returnData['fileName'] = '';
        $returnData['message'] = '';
        $imageSize = \Config::get('constants.ImageSize');

        $inputFile = !empty($params['file']) ? $params['file'] : array();
        $file = array('image' => $inputFile);

        $rules = array('image' => 'required|mimes:jpeg,jpg,png|image|max:' . $imageSize);

        $validator = \Validator::make($file, $rules);

        if ($validator->fails()) {
            $errorMessages = $validator->errors()->all();
            //$errorMessages =  __('messages.ImageNotSaved');

            $returnData['message'] = $errorMessages;
        } else {
            if ($inputFile->isValid()) {
                $fileName = !empty($params['file_name']) ? $params['file_name'] : substr($params['file']->getClientOriginalName(), 0, 50) . '_' . rand(100, 999) . time(); // renaming image
                $fileResize = !empty($params['fileResize']) ? $params['fileResize'] : false;
                $fileCrop = !empty($params['fileCrop']) ? $params['fileCrop'] : false;
                $width = !empty($params['width']) ? (int) $params['width'] : 100;
                $height = !empty($params['height']) ? (int) $params['height'] : 100;
                $xCord = !empty($params['xCord']) ? (int)$params['xCord'] : 0;
                $yCord = !empty($params['yCord']) ? (int)$params['yCord'] : 0;
                $isThumb = !empty($params['isThumb']) ? $params['isThumb'] : false;
                $thumbWidth = !empty($params['thumbWidth']) ? $params['thumbWidth'] : 100;
                $thumbHeight = !empty($params['thumbHeight']) ? $params['thumbHeight'] : 100;
                $savePath = !empty($params['savePath']) ? 'public/' . $params['savePath'] : 'public/mix';
                $thumbSavePath = !empty($params['thumbSavePath']) ? 'public/' . $params['thumbSavePath'] : 'public/mix/thumb/';
				
                try {                    
                    // getting image extension
                    $extension = $inputFile->getClientOriginalExtension();

                    // The below code will remove anything that is not a-z, 0-9 or a dot.
                    $fileName = preg_replace("/[^a-zA-Z0-9.]/", "", $fileName);

                    $fileName = str_replace('.' . $extension, '', $fileName) . '.' . $extension;

                    $allowed_ext = array('jpeg', 'jpg', 'png');

                    if (in_array($extension, $allowed_ext)) {
                        //check directory exists
                        if(!Storage::exists($savePath)) {
                            Storage::makeDirectory($savePath, 0777, true);
                        }
                        
                        //create image
                        $image = Image::make($inputFile); //$inputFile->getRealPath()
                      
                        // uploading file to given path
                        if ($fileResize) {
                            $image->resize($width, $height, function ($constraint) {
                                $constraint->aspectRatio();
                            });
                        } elseif ($fileCrop) {
                            $image->crop($width, $height, $xCord, $yCord);
                        } else {
                            
                        }
                        
                        Storage::putFileAs($savePath, $inputFile, $fileName);

                        if ($isThumb) {
                            $image->fit($thumbWidth, $thumbHeight, function ($constraint) {
                                $constraint->upsize();
                            });
                            
                            Storage::putFileAs($thumbSavePath, $inputFile, $fileName);
                        }
                    } else {
                        $returnData['message'] = __('messages.FileNotValid');
                    }

                    $returnData['status'] = true;
                    $returnData['message'] = __('messages.ImageSaved');
                    $returnData['fileName'] = $fileName;
                    $returnData['savePath'] = $savePath;
                } catch (\Exception $e) {
                    $returnData['message'] = $e->getMessage();
                }
            } else {
                $returnData['message'] = __('messages.FileNotValid');
            }
        }

        return $returnData;
    }
    
    public function deleteImage($path, $fileName, $deleteThumb = false)
    {
        if (!empty($fileName) && Storage::disk('public')->has($path . '/' . $fileName)) {
            Storage::disk('public')->delete($path . '/' . $fileName);
            
            if($deleteThumb){
                @Storage::disk('public')->delete($path . '/thumb/' . $fileName);
            }
        }
    }
    
    public function getCityListByState(Request $request)
    {
        $stateId = !empty($request->get('stateId')) ? $request->get('stateId') : '';

        $query = \App\Models\City::select('name', 'id');

        if (!empty($stateId)) {
            $query->where('state_id', '=', $stateId);
        }

        $cities = $query->orderBy('name', 'asc')->get();

        if (count($cities)) {
            $citiesData = array();
            $citiesData[] = array('text'=>'- select -', 'id'=>'');

            foreach ($cities as $city) {
                $citiesData[] = array('text'=>$city->name, 'id'=>$city->id);
            }

            return $this->sendResponse($citiesData);
        } 
        
        return $this->sendError();
    }
}
