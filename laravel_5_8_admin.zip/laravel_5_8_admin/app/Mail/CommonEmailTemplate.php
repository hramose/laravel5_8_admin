<?php
namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Queue\ShouldQueue;

class CommonEmailTemplate extends Mailable
{
    use Queueable, SerializesModels;
    
    public $params;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct($params)
    {
        $this->params = $params;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        if(!empty($this->params['attachment']))
        {
            return $this->markdown('emails.common_email_template')
                        ->from($this->params['fromEmail'])
                        ->subject($this->params['emailTemplate']['subject'])
                        ->attach($this->params['attachment'], array('as' => $this->params['originalFileName'])); 
        }
        else
        {
            return $this->markdown('emails.common_email_template')
                        ->from($this->params['fromEmail'])
                        ->subject($this->params['emailTemplate']['subject']);
        }
    }
}
