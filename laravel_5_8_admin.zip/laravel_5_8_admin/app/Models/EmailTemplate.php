<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class EmailTemplate extends Model {
    use Sortable;
    
    protected $guarded = ['_token'];    
    protected $hidden = ['_token', 'created_at', 'updated_at'];
    public $sortable = ['id', 'subject', 'created_at'];
    
    public function rules()
    {
        return [
            'type' => 'required',
            'subject' => 'required',
            'body' => 'required',
        ];
    }
    
    // @Author:     
    // @description : Below function uses for return Email template
    // @param $slug:string
    // @return \Illuminate\Http\Response
    public function fetchEmailTemplateBySlug($slug = null) {
        if (!empty($slug)) {
            $emailTemplate = EmailTemplate::where('slug', '=', $slug)->first();

            if (!empty($emailTemplate))
                $emailTemplate = $emailTemplate->toArray();

            return $emailTemplate;
        }
    }
    
    public function fetchAllEmailTemplates()
    {
        return EmailTemplate::sortable(['created_at' => 'desc'])->paginate(config('AdminPageSize'));
    }
}
