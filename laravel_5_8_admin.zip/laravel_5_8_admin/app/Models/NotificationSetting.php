<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NotificationSetting extends Model {
    protected $fillable = ['user_id', 'want_rating_review_email', 'want_profile_review_email', 'want_payment_email'];
    
    public function user(){
        return $this->belongsTo('App\Models\User');
    }
}

