<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class SmtpSetting extends Model
{
    use Sortable;

    protected $guarded = ['_token'];
    protected $hidden = ['created_at', 'updated_at'];
    public $sortable = ['id', 'name', 'value', 'created_at'];
    
    public function rules()
    {
        $rules = [
            'driver' => 'required',
            'host' => 'required',
            'port' => 'required',
            'username' => 'required',
            'password' => 'required',
            'encryption' => 'required'
        ];
        
        return $rules;
    }
}
