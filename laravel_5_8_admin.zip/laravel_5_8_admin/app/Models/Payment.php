<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Payment extends Model {
    use Sortable;
    protected $guarded = ['_token'];
    protected $hidden = ['updated_at'];   

    public $sortable = ['id', 'pay_amount', 'transaction_id', 'transaction_date_time'];
    
    public function User(){
        return $this->belongsTo('App\Models\User', 'user_id')->select('id', 'first_name', 'last_name', 'email', 'image');
    }

    public function Subscription(){
        return $this->belongsTo('App\Models\Subscription', 'subscription_id')->select('id', 'type');
    }

    public function getAllPayments($request)
    {
        $search = !empty($request->search) ? $request->search : '';
        $convert = \DB::raw("cast(created_at as date)");
        $from = date('Y-m-d', strtotime($request->start_date));
        $to = !empty($request->end_date) ? date('Y-m-d', strtotime($request->end_date)) : date('Y-m-d') ;

        $query = Payment::with('User', 'Subscription')->whereIn('status', ['failed', 'complete']);

        if (!empty($search)) {
            $query->where('transaction_id', 'LIKE', "%$search%");
        }

        if(!empty($request->start_date)){
            $query->whereBetween($convert, [$from, $to]);
        }

        $payments = $query->sortable(['id' => 'desc'])->paginate(config('AdminPageSize'));

        return $payments;
    }
}
