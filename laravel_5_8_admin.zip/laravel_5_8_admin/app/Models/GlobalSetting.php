<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class GlobalSetting extends Model
{
    use Sortable;

    protected $guarded = ['_token'];
    protected $hidden = ['created_at', 'updated_at'];
    public $sortable = ['id', 'name', 'value', 'created_at'];
    
    public function fetchAllGlobalSettings($request)
    {
        $globalSettings = GlobalSetting::sortable(['name' => 'asc'])->get();

        return $globalSettings;
    }
}
