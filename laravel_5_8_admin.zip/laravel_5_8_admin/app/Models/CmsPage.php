<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class CmsPage extends Model {
    use Sortable;

    protected $guarded = ['_token'];
    protected $hidden = ['_token', 'created_at', 'updated_at'];
    public $sortable = ['id', 'title', 'heading', 'created_at'];

    public function rules() {
        return [
            'title' => 'required|min:2|max:255',
            'slug' => 'required',
            'meta_key' => 'nullable|min:2|max:255',
            'meta_description' => 'nullable|min:2|max:255',
            'description' => 'required|min:2',
        ];
    }

    public function fetchAllCmsPages($request) {
        $search = !empty($request->search) ? $request->search : '';

        $query = CmsPage::query();

        if (!empty($search)) {
            $query->whereRaw(\DB::raw('(title like "%' . $search . '%")'));
        }

        $cmsPages = $query->sortable(['title' => 'asc'])->paginate(config('AdminPageSize'));

        return $cmsPages;
    }
}