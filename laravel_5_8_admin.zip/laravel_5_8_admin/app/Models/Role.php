<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Role extends Model {
    public static function hasRole($roleDisplayName = null) {
        $loginUserRoleId = \Auth::user()->role_id;
        
        $role = Role::where('id', '=', $loginUserRoleId)->first();
        
        if(!empty($role->display_name))
        {
            if($role->display_name == $roleDisplayName)
            {
                return true;
            }
        }        
        
        return false;
    }
}
