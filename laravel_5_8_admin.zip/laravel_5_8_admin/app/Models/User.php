<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class User extends Model {
    use Sortable;
    
    protected $guarded = ['_token'];
    protected $hidden = ['created_at', 'updated_at', 'password_confirmation', 'remember_token'];
    
    public $sortable = ['id', 'first_name', 'last_name', 'fullname', 'email', 'created_at'];

    public function rules($user = null)
    {
        $imageSize = \Config::get('constants.ImageSize');
        
        return [
            'first_name' => 'required',
            'last_name' => 'required',
            'username' => 'required|unique:users,username,' . ($user->id ? $user->id : '') . '|max:191',
            'image' => 'nullable|image|mimes:jpeg,jpg,png|max:' . $imageSize,
            'contact_number' => 'nullable|between:8,20',
            'email' => 'required|unique:users,email, ' . ($user->id ? $user->id : '') . ',id,role_id,' . ($user->role_id ? $user->role_id : ''),
            'country_id' => 'required',
            'status' => 'required',
        ];
    }
    
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function signUpRules()
    {
        return [
            'email' => 'required|unique:users|between:5,191',
            'name' => 'required|between:2,191',
            'contact_number' => 'nullable|between:8,15',
            'password' => 'required|between:8,15|confirmed'
        ];
    }
    
    public function editRules()
    {
        return [
            'email' => 'required|between:5,191',
            'name' => 'required|between:2,191',
            'contact_number' => 'nullable|between:8,15'
        ];
    }
    
    public function messages()
    {
        return [
            'username.unique' => 'The username already exists.',
            'email.unique' => 'The email already exists.',
        ];
    }
    
    public function Role(){
        return $this->belongsTo('App\Models\Role');
    }
    
    public function Country()
    {
        return $this->belongsTo('App\Models\Country');
    }
    
    public function State()
    {
        return $this->belongsTo('App\Models\State');
    }
    
    public function City()
    {
        return $this->belongsTo('App\Models\City');
    }

    public function fullNameSortable($query, $direction) {
        return $query->orderBy('first_name', $direction)->orderBy('last_name', $direction);
    }

    public function getFullNameAttribute() {
        return ucfirst($this->first_name . ' ' . $this->last_name);
    }
    
    public function fetchAllUsers($request, $roleName = null)
    {
        $pageSize = config('AdminPageSize');
        $search = !empty($request->search) ? $request->search : '';
        $convert = \DB::raw("cast(created_at as date)");
        $from = date('Y-m-d', strtotime($request->start_date));
        $to = !empty($request->end_date) ? date('Y-m-d', strtotime($request->end_date)) : date('Y-m-d') ;

        $query = User::with('Country', 'State', 'City')
                        ->whereHas('Role', function($q) use($roleName){
                            $q->where('name', '=', $roleName);
                        });

        if (!empty($search)) {
            $query->where(function($q) use($search){
                $q->where('email', 'LIKE', "%$search%")
                ->orWhereRaw("concat(first_name, ' ', last_name) like '%$search%' ");
            });
        }

        if(!empty($request->start_date)){
            $query->whereBetween($convert, [$from, $to]);
        }

        $users = $query->sortable(['created_at' => 'desc'])->paginate($pageSize);

        return $users;
    }
}
