<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class Category extends Model {
    use Sortable;

    protected $guarded = ['_token'];
    public $sortable = ['id', 'name', 'status'];
    protected $hidden = ['_token', 'created_at', 'updated_at'];
    
    public function rules($id = null) {
        return [
            'name' => 'required|unique:categories,name,' . ($id ? $id : '') . '|between:2,255',
            'status' => 'required'
        ];
    }
    
    public function fetchAllCategories($request) {
        $search = !empty($request->search) ? $request->search : '';

        $query = Category::query();

        if (!empty($search)) {
            $query->where('name', 'LIKE', "%$search%");
        }
        
        $categories = $query->sortable(['created_at' => 'desc'])->paginate(config('AdminPageSize'));
        
        return $categories;
    }
}