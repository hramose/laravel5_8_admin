<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Kyslik\ColumnSortable\Sortable;

class MailingAddressesSetting extends Model
{
    use Sortable;

    protected $guarded = ['_token'];
    protected $hidden = ['created_at', 'updated_at'];
    public $sortable = ['id', 'name', 'value', 'created_at'];
    
    public function rules()
    {
        $rules = [
            'admin_email_id' => 'required',
            'support_email_id' => 'required',
            'no_reply_email_id' => 'required',
            'contact_us_email_id' => 'required'
        ];
        
        return $rules;
    }
}

