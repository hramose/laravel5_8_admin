<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RecordImage extends Model
{
    public $timestamps = false;
    
    protected $fillable = ['record_id', 'type', 'image'];    
}
