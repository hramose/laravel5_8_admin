<?php
namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class ConfigServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        $globalSetting = \App\Models\GlobalSetting::pluck('value', 'name')->toArray();
        
        config()->set(['AdminPageSize' => $globalSetting['AdminPageSize'],
            'SiteName' => $globalSetting['SiteName']
        ]);
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
